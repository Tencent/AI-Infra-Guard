# AIG Scan Plugin for OpenClaw

## Install

在 OpenClaw 对话中说：

```
帮我安装并启用 AIG Scan Plugin
下载地址：https://github.com/Tencent/AI-Infra-Guard/raw/main/openclaw/aig-scan-plugin.tgz
```

或手动：

```bash
openclaw plugins install aig-scan-plugin.tgz
openclaw plugins enable aig-scan-plugin
```

## Config

默认连接 `http://localhost:8088`，本机 AIG 无需额外配置。

```bash
# AIG 在远程时指定地址
openclaw config set plugins.entries.aig-scan-plugin.config.serverUrl http://your-aig-host:8088

# AIG 开启认证时
openclaw config set plugins.entries.aig-scan-plugin.config.apiKey YOUR_AIG_API_KEY

# AI Tool / Skills Scan 需要分析模型（配一次即可）
openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.model gpt-4o
openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.token sk-xxx
openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.base_url https://api.openai.com/v1
```

## Tools

| Tool | Description |
|------|-------------|
| `aig_scan_infra` | AI 服务漏洞/配置扫描 |
| `aig_scan_ai_tools` | AI 工具 / Skills 安全审计 |
| `aig_scan_agent` | AI Agent 安全扫描 |
| `aig_scan_model_safety` | 大模型越狱/红队评测 |
| `aig_check_scan_result` | 查询扫描进度和结果 |
| `aig_list_agents` | 列出可扫描的 Agent 配置 |

---

Powered by Tencent Zhuque Lab [A.I.G](https://github.com/Tencent/AI-Infra-Guard)
