import { describe, expect, it, vi } from "vitest";
import registerAigSecurity from "./index.js";

describe("aig-scan-plugin plugin registration", () => {
  it("registers all tools with plugin-side polling config", () => {
    const registerTool = vi.fn();

    registerAigSecurity({
      id: "aig-scan-plugin",
      name: "AIG Security",
      description: "AIG Security",
      source: "test",
      config: {
        plugins: {
          entries: {
            "aig-scan-plugin": {
              config: {
                serverUrl: "http://localhost:8088",
                apiKey: "test-key",
                submitPollIntervalMs: 3_000,
                submitMaxWaitMs: 12_000,
                monitorPollIntervalMs: 4_000,
                monitorMaxWaitMs: 30_000,
              },
            },
          },
        },
      },
      pluginConfig: {},
      runtime: {} as never,
      logger: {
        info() {},
        warn() {},
        error() {},
      },
      registerTool,
      registerHook() {},
      registerHttpRoute() {},
      registerChannel() {},
      registerGatewayMethod() {},
      registerCli() {},
      registerService() {},
      registerProvider() {},
      registerCommand() {},
      registerContextEngine() {},
      resolvePath(input: string) {
        return input;
      },
      on() {},
    });

    expect(registerTool).toHaveBeenCalledTimes(6);
  });

  it("marks completed scan reports as direct passthrough content in every tool description", () => {
    const registerTool = vi.fn();

    registerAigSecurity({
      id: "aig-scan-plugin",
      name: "AIG Security",
      description: "AIG Security",
      source: "test",
      config: {
        plugins: {
          entries: {
            "aig-scan-plugin": {
              config: {
                serverUrl: "http://localhost:8088",
              },
            },
          },
        },
      },
      pluginConfig: {},
      runtime: {} as never,
      logger: {
        info() {},
        warn() {},
        error() {},
      },
      registerTool,
      registerHook() {},
      registerHttpRoute() {},
      registerChannel() {},
      registerGatewayMethod() {},
      registerCli() {},
      registerService() {},
      registerProvider() {},
      registerCommand() {},
      registerContextEngine() {},
      resolvePath(input: string) {
        return input;
      },
      on() {},
    });

    const descriptions = registerTool.mock.calls.map(([factory]) => {
      const tool = factory({
        sessionKey: "agent:test:web:user-1",
        agentId: "test",
      });
      return String(tool?.description ?? "");
    });
    const passthroughDescriptions = descriptions.filter((text) =>
      text.includes("passthrough the full report exactly")
      || text.includes("output that report block directly and completely"),
    );

    expect(passthroughDescriptions).toHaveLength(5);
    expect(descriptions.some((text) => text.includes("List Agent configs currently visible"))).toBe(true);
  });
});
