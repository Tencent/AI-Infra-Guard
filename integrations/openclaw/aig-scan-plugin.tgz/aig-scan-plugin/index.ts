/**
 * AIG Security Scanner — OpenClaw Plugin
 *
 * Provides conversational access to AI-Infra-Guard (AIG) security scanning:
 *   - aig_scan_infra    → AI infrastructure CVE / misconfiguration scan
 *   - aig_scan_ai_tools → AI tool / skills security scan (supports MCP / Skills)
 *   - aig_scan_model_safety → LLM jailbreak red-team evaluation
 *   - aig_scan_agent    → AI Agent security scan (Dify / Coze / HTTP)
 *   - aig_list_agents   → List visible AIG Agent configs for the current username namespace
 *   - aig_check_scan_result → Poll any async task for progress + results
 *
 * Prerequisites:
 *   AIG server must be running (for opensource: docker compose up in aig-opensource/).
 *   Configure plugins.entries.aig-scan-plugin.config.serverUrl and .apiKey if needed.
 */

import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
import { InMemoryAigMonitor } from "./src/background-monitor.js";
import { createAigClient } from "./src/client.js";
import { createAigTaskNotifier } from "./src/notifier.js";
import { resolvePollingOptions } from "./src/poll.js";
import { createScanModelSafetyTool } from "./src/tools/scan-model-safety.js";
import { createScanAgentTool } from "./src/tools/scan-agent.js";
import { createScanAiToolsTool } from "./src/tools/scan-ai-tools.js";
import { createScanInfraTool } from "./src/tools/scan-infra.js";
import { createCheckScanResultTool } from "./src/tools/check-scan-result.js";
import { createListAgentsTool } from "./src/tools/list-agents.js";

export default function register(api: OpenClawPluginApi) {
  // Read plugin config (set via: openclaw config set plugins.entries.aig-scan-plugin.config.*)
  const cfg = (api.config.plugins?.entries?.["aig-scan-plugin"]?.config ?? {}) as {
    serverUrl?: string;
    apiKey?: string;
    username?: string;
    submitPollIntervalMs?: number;
    submitMaxWaitMs?: number;
    monitorPollIntervalMs?: number;
    monitorMaxWaitMs?: number;
    /**
     * Default analysis model for AI tool / skills scan tasks.
     * Required for aig-opensource which removed server-side model auto-resolution.
     * Set via: openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.model "gpt-4o"
     *          openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.token "sk-xxx"
     *          openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.base_url "https://..."
     */
    defaultModel?: {
      model: string;
      token: string;
      base_url?: string;
    };
  };

  const client = createAigClient({
    serverUrl: cfg.serverUrl,
    apiKey: cfg.apiKey,
    username: cfg.username,
  });
  const polling = resolvePollingOptions(cfg);
  const notifier = createAigTaskNotifier({
    config: api.config,
    logger: api.logger,
    formatResultOpts: { serverUrl: client.serverUrl },
  });
  const monitor = new InMemoryAigMonitor(client, api.logger, {
    intervalMs: polling.monitorPollIntervalMs,
    maxWaitMs: 35 * 60 * 1000,
  }, notifier);

  api.logger.info(
    `[aig-scan-plugin] Plugin loaded. AIG server: ${cfg.serverUrl ?? "http://localhost:8088"}`,
  );

  // Register all tools
  api.registerTool((ctx) =>
    createScanInfraTool(client, polling, monitor, {
      sessionKey: ctx.sessionKey,
      agentId: ctx.agentId,
    }),
  );
  api.registerTool((ctx) =>
    createScanAiToolsTool(client, polling, monitor, cfg.defaultModel, {
      sessionKey: ctx.sessionKey,
      agentId: ctx.agentId,
    }),
  );
  api.registerTool((ctx) =>
    createScanModelSafetyTool(client, polling, monitor, {
      sessionKey: ctx.sessionKey,
      agentId: ctx.agentId,
    }),
  );
  api.registerTool((ctx) =>
    createScanAgentTool(client, polling, monitor, {
      sessionKey: ctx.sessionKey,
      agentId: ctx.agentId,
    }),
  );
  api.registerTool(() => createListAgentsTool(client));
  api.registerTool((ctx) =>
    createCheckScanResultTool(client, polling, monitor, {
      sessionKey: ctx.sessionKey,
      agentId: ctx.agentId,
    }),
  );
}
