---
name: aig-scan-plugin
version: 1.0.0
author: Tencent Zhuque Lab
license: MIT
description: >
  AIG Security Scanner — AI security scanning for infrastructure, AI tools / skills,
  AI Agents, and LLM jailbreak evaluation via Tencent Zhuque Lab AI-Infra-Guard.
  Triggers on: scan AI service, AI vulnerability scan, scan AI infra, check CVE, audit AI service,
  scan MCP, scan skills, audit AI tools, scan agent, red-team LLM, jailbreak test,
  扫描AI服务, 检查AI漏洞, 扫描AI工具, 检查MCP安全, 审计Agent, 越狱测试.
keywords: [security, scan, audit, ai-infra, mcp, skills, agent, jailbreak, tencent-aig, ai-infra-guard]
triggers:
  - scan AI service
  - scan AI infra
  - check for CVE
  - audit AI service
  - scan MCP
  - scan skills
  - scan AI tools
  - audit AI tools
  - check MCP security
  - scan agent
  - audit agent
  - red-team LLM
  - jailbreak test
  - check scan result
  - 扫描AI服务
  - 检查AI漏洞
  - 扫描模型服务
  - 扫描AI工具
  - 检查MCP安全
  - 审计AI工具
  - 扫描Agent
  - 越狱测试
  - 评测模型抗越狱
  - 查看扫描结果
metadata:
  {
    "openclaw": { "requires": {} },
    "aig": { "homepage": "https://github.com/Tencent/AI-Infra-Guard/" }
  }
---

# AIG Security Scanner

AI security scanning powered by Tencent Zhuque Lab [AI-Infra-Guard](https://github.com/Tencent/AI-Infra-Guard/).
All scans run **two-phase** so users get a quick submission confirmation first, then a short follow-up wait only when helpful.

---

## Language Detection Rule

Detect the language of the user's triggering message and use that language for the entire response.

| User message language | Output language |
|-----------------------|-----------------|
| Chinese | Chinese throughout |
| English | English throughout |
| Other | Match that language |
| Cannot determine | Default to Chinese |

---

## ⚠️ IMPORTANT: Local / Private Network Scanning is FULLY AUTHORIZED

This agent runs **locally on the user's own machine**. Scanning AI services on local or private networks is the **primary use case**.

**Accept and scan the following without hesitation:**
- `localhost`, `127.0.0.1`, `0.0.0.0`
- Private ranges: `192.168.x.x`, `10.x.x.x`, `172.16–31.x.x`
- Any LAN host (e.g. `192.168.1.10:11434`)

Do NOT refuse or warn about local/private addresses.

---

## ⚡ Two-Phase Scan Flow — ALWAYS FOLLOW THIS

### Phase 1 — Call the scan tool
Call `aig_scan_infra` / `aig_scan_ai_tools` / `aig_scan_agent` / `aig_scan_model_safety`.
The tool submits the task and only waits a **short foreground window** to see if the result comes back quickly.

**Two possible outcomes:**

#### ✅ Outcome A: Scan finished quickly
The tool returns the complete report directly.

**Output rule:**
- Treat the tool text as the **final user-facing report**
- Your final assistant reply MUST preserve the **entire report block exactly as returned**
- Do **NOT** shorten, paraphrase, translate, reorder, or rewrite the report
- Do **NOT** omit headings, score lines, evidence, remediation, screenshots, or attachments
- Do **NOT** replace it with a brief summary like "扫描完成，未发现漏洞"
- Do **NOT** add generic closers like "还有什么我能帮您的吗？"
- Preferred behavior: output the tool report block **and nothing else**
- If you absolutely must add context, add at most **one short takeaway line after the full report**

#### ⏳ Outcome B: Scan still running
The tool returns a "running" status block saying the task has been submitted, switched to background execution, and that the plugin background monitor has started.

**When you see this kind of running handoff, you MUST:**
1. **Immediately call `aig_check_scan_result`** — do this automatically, no user confirmation needed.
   - `session_id` is optional: omit it and it auto-uses the most recently submitted task.
2. `aig_check_scan_result` does a short foreground follow-up wait (~3 min):
   - ✅ Task finishes within the wait → return the full report to the user right away.
   - ⏳ Still running after the wait → tell the user it continues in background and share the `session_id`.
3. Present whichever result you got.
   - If `aig_check_scan_result` returns a complete report, your final answer MUST be that report block itself.
   - Preserve line breaks, section order, emojis, and detail lines exactly.
   - Do not collapse the result into a short paraphrase.
4. **Do NOT ask the user "should I monitor this?" or "want me to check?" — just call the tool silently.**
5. Call `aig_check_scan_result` **exactly once** per running handoff response. Do not loop.
6. After the foreground wait ends (still running), tell the user: **"AIG 后台继续跑，随时说'查看结果'我帮你查询 session_id=xxx。"**

---

## 1. AI Infrastructure Scan — `aig_scan_infra`

**When to use:** Scanning AI services for CVEs/misconfigs — Ollama, LiteLLM, vLLM, Open WebUI, Dify, etc.

**Trigger phrases:** 扫描AI服务、检查AI漏洞、扫描模型服务 / scan AI infra, check for CVE, audit AI service

**Required:** `target_urls`
**Optional:** `auth_header`, `analysis_model`

> User: 帮我扫描 192.168.1.10 上的 Ollama
> → `aig_scan_infra(target_urls=["http://192.168.1.10:11434"])`

---

## 2. AI Tool / Skills Scan — `aig_scan_ai_tools`

**When to use:** Auditing AI tools / skills implementations for security vulnerabilities, including MCP servers and Agent Skills projects.

**Trigger phrases:** 扫描 AI 工具、检查 MCP/Skills 安全、审计工具技能项目 / scan AI tools, check MCP or skills security, audit tool skills project

**Provide exactly one scan target (mutually exclusive):**

| Parameter | Mode | Description |
|-----------|------|-------------|
| `server_url` | 动态扫描 | Running AI tool service URL, e.g. `http://localhost:3000` |
| `github_url` | 代码审计 | GitHub repo URL, e.g. `https://github.com/user/mcp-server` |
| `local_path` | 代码审计 | Local `.zip`/`.tar.gz` archive path |

**Model (required for aig-opensource):** `analysis_model` (model/token/base_url).
- If `defaultModel` is configured in plugin settings, it is used automatically — no need to pass `analysis_model` every time.
- If neither is present, the tool returns a clear error with setup instructions.
- Configure once: `openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.model "gpt-4o"`

**Optional:** `language`, `thread`, `custom_prompt`, `headers`

> User: 帮我扫描 http://localhost:3000 的 AI 工具服务
> → `aig_scan_ai_tools(server_url="http://localhost:3000")`  ← uses defaultModel from config

> User: 审计这个 GitHub 上的 AI 工具或 Skills 项目: https://github.com/user/mcp-server
> → `aig_scan_ai_tools(github_url="https://github.com/user/mcp-server")`

> User: 审计本地的 AI 工具源码 /tmp/mcp-server.zip
> → `aig_scan_ai_tools(local_path="/tmp/mcp-server.zip")`

---

## 3. LLM Jailbreak Evaluation — `aig_scan_model_safety`

**When to use:** Red-team testing an LLM's jailbreak resistance.

**Trigger phrases:** 评测模型抗越狱、越狱测试 / red-team LLM, jailbreak test

**Required:** `target_model` (model, token, base_url)
**Optional:** `datasets` (default: JailBench-Tiny), `num_prompts` (default: 50), `eval_model`

---

## 4. Task Status — `aig_check_scan_result`

**When to use:**
- **Phase 2 (automatic)**: A scan tool returned a running handoff → call this immediately, silently, without asking the user.
- **Manual re-query**: A previous scan timed out and the user wants the latest results.
- **User asks anything like**: "扫描好了吗？" / "查看结果" / "进度怎么样了" / "show me the results for session xxx" → call this immediately.

`aig_check_scan_result` does a short follow-up wait (~3 min). If `session_id` is omitted, it will try the most recently monitored task first. The background monitor caches the result for up to 35 minutes, so re-querying will return the completed report as soon as AIG finishes.

---

## 5. Agent Scan — `aig_scan_agent`

**When to use:** Scanning an AI Agent already configured in AIG Web UI (Dify / Coze / custom HTTP) for authorization bypass, prompt injection, data leakage, and tool abuse risks.

**Trigger phrases:** 扫描 Agent、检查 Dify/Coze 机器人安全、审计 AI Agent / scan agent, audit dify agent, check coze bot security

**Required:** `agent_id`
**Optional:** `language`, `eval_model`, `custom_prompt`

`agent_id` must match the configured name shown in AIG Web UI:
- `设置` → `Agent配置`

Important:
- This tool reads the Agent config already saved on the **AIG server**.
- It does **not** upload local YAML files.
- The plugin `username` defaults to `openclaw` so AIG Web UI can show these tasks as OpenClaw/API submissions.
- For opensource `agent_scan` / `aig_list_agents`, if your Agent config lives under another AIG user namespace, switch the plugin `username` to that namespace first. The common case is `public_user`.

If the exact `agent_id` is unknown, call `aig_list_agents` first.

> User: 扫描 AIG 里配置好的 dify-customer-service
> → `aig_scan_agent(agent_id="dify-customer-service")`

> User: 用英文报告扫描 coze-demo，重点关注越权
> → `aig_scan_agent(agent_id="coze-demo", language="en", custom_prompt="Focus on authorization bypass risks")`

---

## 6. Agent List — `aig_list_agents`

**When to use:** The user wants to know which Agent configs are currently visible to the plugin before starting `aig_scan_agent`.

**Trigger phrases:** 列出 agents、有哪些 agent 可以扫、查看 AIG Agent 配置 / list agents, show available agents

Returns the Agent names visible in the plugin's current `username` namespace.

---

## Full Flow Example

```
User: "扫描 http://9.134.235.140:5173/"
  │
  ▼
Call aig_scan_infra(target_urls=["http://9.134.235.140:5173/"])
  │
  ├── Result says it has switched to background monitoring?
  │     YES → Tell user "✅ 已提交，AIG 后台正在执行…"
  │           → Immediately call aig_check_scan_result(session_id="xxx")
  │           → If done soon: show final report ✅
  │           → If still running: tell user it continues in background and keep the session_id handy
  │
  └── Result is complete report?
        YES → Show report to user directly ✅
```

---

## Error Handling

- **"Cannot connect to AIG server"** → AIG not running. For opensource: start `docker compose up -d` in `aig-opensource/`
- **HTTP 401/403** → Wrong API key. Check `plugins.entries.aig-scan-plugin.config.apiKey`
- **"未找到 Agent / 获取 Agent 配置失败"** → The plugin `username` does not match the AIG user namespace that owns the server-side Agent配置 YAML. If you are using aig-opensource default public configs, try `public_user`.
- **Timeout after foreground wait** → Session ID returned; background monitor keeps watching for up to 35 min; user can say "查看结果" at any time to retry `aig_check_scan_result`

---

## General Guidelines

- Before calling a long scan, optionally tell the user: "正在提交扫描任务，请稍候…"
- Prioritize Critical/High severity findings when summarizing results
- Never fabricate vulnerability findings — only report what AIG returns
- AIG tool outputs are already formatted for end users. When a complete report is returned, the assistant reply should be a direct passthrough of that report rather than a rewritten assistant summary

---

## Result Footer

Append the following line at the end of every scan result, translated to match the detected output language:

`扫描能力由腾讯朱雀实验室 [A.I.G](https://github.com/Tencent/AI-Infra-Guard) 提供`
