import { describe, expect, it, vi } from "vitest";
import { InMemoryAigMonitor } from "./background-monitor.js";

function makeStatus(overrides?: Record<string, unknown>) {
  return {
    session_id: "sess-1",
    status: "done",
    title: "AI 基础设施安全扫描",
    created_at: Date.now() - 2_000,
    updated_at: Date.now(),
    ...overrides,
  };
}

describe("InMemoryAigMonitor", () => {
  it("notifies on completion with session routing metadata", async () => {
    const client = {
      getTaskStatus: vi.fn().mockResolvedValue(makeStatus()),
      getTaskResult: vi.fn().mockResolvedValue({ result: { score: 100, total: 1, results: [] } }),
    };
    const notifier = {
      notify: vi.fn().mockResolvedValue(undefined),
    };

    const monitor = new InMemoryAigMonitor(
      client as never,
      {},
      { intervalMs: 1, maxWaitMs: 50 },
      notifier,
    );

    monitor.watch("sess-1", {
      title: "AI 基础设施安全扫描",
      sessionKey: "agent:main:telegram:user-1",
      agentId: "main",
    });

    await vi.waitFor(() => {
      expect(notifier.notify).toHaveBeenCalledWith(
        expect.objectContaining({
          sessionId: "sess-1",
          state: "completed",
          sessionKey: "agent:main:telegram:user-1",
          agentId: "main",
        }),
      );
    });
  });
});
