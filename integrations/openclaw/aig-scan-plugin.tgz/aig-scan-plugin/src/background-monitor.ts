import type { AigClient } from "./client.js";
import {
  detectStuckReason,
  isCompleted,
  isFailed,
  sleep,
} from "./poll.js";
import type { AigTaskStatusData } from "./types.js";

export type AigMonitorSnapshot = {
  sessionId: string;
  title: string;
  sessionKey?: string;
  agentId?: string;
  state: "running" | "completed" | "failed" | "stuck";
  startedAt: number;
  lastCheckedAt: number;
  status?: AigTaskStatusData;
  result?: unknown;
  reason?: string;
};

export type AigTaskNotifier = {
  notify(snapshot: AigMonitorSnapshot): Promise<void>;
};

export type AigMonitor = {
  watch(sessionId: string, meta: { title: string; sessionKey?: string; agentId?: string }): void;
  getSnapshot(sessionId: string): AigMonitorSnapshot | undefined;
  getLatestSessionId(sessionKey?: string): string | undefined;
};

type BackgroundMonitorOptions = {
  intervalMs: number;
  maxWaitMs: number;
};

type MonitorLogger = {
  info?: (message: string) => void;
  warn?: (message: string) => void;
  error?: (message: string) => void;
};

const DEFAULT_OPTIONS: BackgroundMonitorOptions = {
  intervalMs: 5_000,
  maxWaitMs: 35 * 60 * 1000, // 35 min — covers GitHub clones + large jailbreak datasets
};

type InternalSnapshot = AigMonitorSnapshot & {
  monitorStartedAt: number;
};

export class InMemoryAigMonitor implements AigMonitor {
  private readonly entries = new Map<string, InternalSnapshot>();
  private latestSessionId?: string;
  private readonly latestBySessionKey = new Map<string, string>();

  constructor(
    private readonly client: AigClient,
    private readonly logger: MonitorLogger,
    private readonly options: BackgroundMonitorOptions = DEFAULT_OPTIONS,
    private readonly notifier?: AigTaskNotifier,
  ) {}

  watch(sessionId: string, meta: { title: string; sessionKey?: string; agentId?: string }): void {
    this.latestSessionId = sessionId;
    if (meta.sessionKey) {
      this.latestBySessionKey.set(meta.sessionKey, sessionId);
    }

    const current = this.entries.get(sessionId);
    if (current) {
      current.title = meta.title || current.title;
      current.sessionKey = meta.sessionKey ?? current.sessionKey;
      current.agentId = meta.agentId ?? current.agentId;
      if (current.state === "running") return;
    }

    const snapshot: InternalSnapshot = {
      sessionId,
      title: meta.title,
      sessionKey: meta.sessionKey,
      agentId: meta.agentId,
      state: "running",
      startedAt: Date.now(),
      monitorStartedAt: Date.now(),
      lastCheckedAt: 0,
    };
    this.entries.set(sessionId, snapshot);
    void this.run(sessionId);
  }

  getSnapshot(sessionId: string): AigMonitorSnapshot | undefined {
    const entry = this.entries.get(sessionId);
    if (!entry) return undefined;
    return { ...entry };
  }

  getLatestSessionId(sessionKey?: string): string | undefined {
    if (sessionKey) {
      return this.latestBySessionKey.get(sessionKey);
    }
    return this.latestSessionId;
  }

  private async run(sessionId: string): Promise<void> {
    while (true) {
      const snapshot = this.entries.get(sessionId);
      if (!snapshot || snapshot.state !== "running") return;

      if (Date.now() - snapshot.monitorStartedAt >= this.options.maxWaitMs) {
        snapshot.state = "stuck";
        snapshot.reason = "插件后台监控已超时，AIG 任务长时间未结束。";
        snapshot.lastCheckedAt = Date.now();
        this.logger.warn?.(
          `[aig-scan-plugin] Background monitor timed out for ${sessionId}`,
        );
        if (this.notifier) {
          await this.notifier.notify({ ...snapshot });
        }
        return;
      }

      try {
        const status = await this.client.getTaskStatus(sessionId);
        snapshot.status = status;
        snapshot.lastCheckedAt = Date.now();
        snapshot.title = status.title || snapshot.title;

        const stuckReason = detectStuckReason(status);
        if (stuckReason) {
          snapshot.state = "stuck";
          snapshot.reason = stuckReason;
          this.logger.warn?.(
            `[aig-scan-plugin] Background monitor detected stuck task ${sessionId}: ${stuckReason}`,
          );
          if (this.notifier) {
            await this.notifier.notify({ ...snapshot });
          }
          return;
        }

        if (isCompleted(status.status)) {
          snapshot.result = await this.client.getTaskResult(sessionId);
          snapshot.state = "completed";
          this.logger.info?.(
            `[aig-scan-plugin] Background monitor completed ${sessionId}`,
          );
          if (this.notifier) {
            await this.notifier.notify({ ...snapshot });
          }
          return;
        }

        if (isFailed(status.status)) {
          snapshot.state = "failed";
          this.logger.warn?.(
            `[aig-scan-plugin] Background monitor observed failed task ${sessionId}: ${status.status}`,
          );
          if (this.notifier) {
            await this.notifier.notify({ ...snapshot });
          }
          return;
        }
      } catch (err) {
        snapshot.lastCheckedAt = Date.now();
        this.logger.warn?.(
          `[aig-scan-plugin] Background monitor polling failed for ${sessionId}: ${String(err)}`,
        );
      }

      await sleep(this.options.intervalMs);
    }
  }
}
