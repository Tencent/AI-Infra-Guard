import fs from "node:fs/promises";
import path from "node:path";
import type {
  AigCreateTaskData,
  AigCreateTaskRequest,
  AigResponse,
  AigTaskStatusData,
  AigUploadData,
} from "./types.js";

/**
 * Lightweight HTTP client for AIG REST API.
 * Auth: API-KEY header (APIKeyMiddleware on /api/v1/app/taskapi/*)
 */
export class AigClient {
  constructor(
    readonly serverUrl: string,
    private readonly apiKey: string,
    readonly username: string,
  ) {}

  // ─── Internal helpers ───────────────────────────────────────────────────────

  private baseHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      username: this.username,
    };
    if (this.apiKey) {
      headers["API-KEY"] = this.apiKey;
    }
    return headers;
  }

  private async request<T>(method: string, urlPath: string, body?: unknown): Promise<T> {
    const url = `${this.serverUrl}${urlPath}`;

    let res: Response;
    try {
      res = await fetch(url, {
        method,
        headers: this.baseHeaders(),
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (err) {
      throw new Error(
        `Cannot connect to AIG server at ${this.serverUrl}. ` +
          `Make sure AIG is running (docker compose up or ./start.sh). ` +
          `Original error: ${String(err)}`,
      );
    }

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`AIG API ${method} ${urlPath} → HTTP ${res.status}: ${text}`);
    }

    const json = (await res.json()) as AigResponse<T>;
    if (json.status !== 0) {
      throw new Error(`AIG API error: ${json.message ?? "unknown error"}`);
    }
    return json.data;
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /** Upload a local file (zip or source) for whitebox scanning. Returns hosted URL. */
  async uploadFile(localPath: string): Promise<AigUploadData> {
    const resolved = path.resolve(localPath);

    let fileBuffer: Buffer;
    let fileName: string;

    try {
      const stat = await fs.stat(resolved);

      if (stat.isDirectory()) {
        // Zip the directory on-the-fly using archiver-free approach: tar via Node child_process
        throw new Error(
          `Directory upload not yet supported. ` +
            `Please zip the directory first: zip -r archive.zip ${resolved}`,
        );
      }

      fileBuffer = await fs.readFile(resolved);
      fileName = path.basename(resolved);
    } catch (err) {
      if (err instanceof Error && err.message.includes("zip")) throw err;
      throw new Error(`Cannot read file at "${localPath}": ${String(err)}`);
    }

    const formData = new FormData();
    formData.append("file", new Blob([new Uint8Array(fileBuffer)]), fileName);

    const url = `${this.serverUrl}/api/v1/app/taskapi/upload`;

    let res: Response;
    try {
      const uploadHeaders: Record<string, string> = {};
      if (this.apiKey) {
        uploadHeaders["API-KEY"] = this.apiKey;
      }
      res = await fetch(url, {
        method: "POST",
        headers: uploadHeaders,
        body: formData,
      });
    } catch (err) {
      throw new Error(`Upload failed — cannot connect to AIG server: ${String(err)}`);
    }

    if (!res.ok) {
      throw new Error(`Upload failed — HTTP ${res.status}`);
    }

    const json = (await res.json()) as AigResponse<AigUploadData>;
    if (json.status !== 0) {
      throw new Error(`Upload failed: ${json.message ?? "unknown error"}`);
    }
    return json.data;
  }

  /** Create an async scan task. Returns session_id. */
  async createTask(req: AigCreateTaskRequest): Promise<AigCreateTaskData> {
    return this.request<AigCreateTaskData>("POST", "/api/v1/app/taskapi/tasks", req);
  }

  /** Poll task status. */
  async getTaskStatus(sessionId: string): Promise<AigTaskStatusData> {
    return this.request<AigTaskStatusData>("GET", `/api/v1/app/taskapi/status/${sessionId}`);
  }

  /** List agent config names visible in the current AIG username namespace. */
  async getAgentNames(): Promise<string[]> {
    return this.request<string[]>("GET", "/api/v1/knowledge/agent/names");
  }

  /**
   * Fetch full scan results.
   * Returns raw JSON — structure depends on task type.
   */
  async getTaskResult(sessionId: string): Promise<unknown> {
    return this.request<unknown>("GET", `/api/v1/app/taskapi/result/${sessionId}`);
  }

  /** Health check — verify AIG is reachable */
  async ping(): Promise<boolean> {
    try {
      const res = await fetch(`${this.serverUrl}/api/v1/app/taskapi/tasks`, {
        method: "OPTIONS",
        signal: AbortSignal.timeout(3000),
      });
      return res.status < 500;
    } catch {
      return false;
    }
  }
}

/** Build AigClient from plugin config, with defaults */
export function createAigClient(params: {
  serverUrl?: string;
  apiKey?: string;
  username?: string;
}): AigClient {
  const serverUrl = (params.serverUrl ?? "http://localhost:8088").replace(/\/$/, "");
  const apiKey = params.apiKey ?? "";
  const username = params.username ?? "openclaw";
  return new AigClient(serverUrl, apiKey, username);
}
