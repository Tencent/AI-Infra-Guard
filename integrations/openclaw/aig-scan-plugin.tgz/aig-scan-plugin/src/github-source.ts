import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

export type PreparedGithubSource = {
  archivePath: string;
  containsRootSkill: boolean;
  cleanup: () => Promise<void>;
};

export async function prepareGithubSource(
  githubUrl: string,
  signal?: AbortSignal,
): Promise<PreparedGithubSource> {
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "aig-github-"));
  const cloneDir = path.join(tempRoot, "repo");
  const archivePath = path.join(tempRoot, "repo.zip");

  try {
    await execFileAsync(
      "git",
      ["clone", "--depth", "1", githubUrl, cloneDir],
      // signal lets the caller abort the subprocess (e.g. on a wall-clock timeout).
      // Keep an internal ceiling so the process never hangs indefinitely on its own.
      { timeout: 5 * 60 * 1000, maxBuffer: 20 * 1024 * 1024, signal },
    );
    await execFileAsync(
      "git",
      ["-C", cloneDir, "archive", "--format=zip", "--output", archivePath, "HEAD"],
      { timeout: 60 * 1000, maxBuffer: 20 * 1024 * 1024, signal },
    );
    const containsRootSkill = await hasFile(path.join(cloneDir, "SKILL.md"));

    return {
      archivePath,
      containsRootSkill,
      cleanup: async () => {
        await fs.rm(tempRoot, { recursive: true, force: true });
      },
    };
  } catch (err) {
    await fs.rm(tempRoot, { recursive: true, force: true });
    throw err;
  }
}

export function buildGithubAuditPrompt(opts: {
  githubUrl: string;
  containsRootSkill: boolean;
  customPrompt?: string;
}): string {
  const lines = [
    `Source repository: ${opts.githubUrl}`,
    opts.containsRootSkill
      ? "目标是 Agent Skills 项目。优先检查 SKILL.md 与 scripts/ 或实际实现的一致性，以及明显恶意行为和高危漏洞。"
      : "目标是 AI 工具协议源码仓库。执行静态代码审计，聚焦中高危漏洞和可利用风险。",
    "优先使用 read_file、list_dir、grep 等静态检索工具；除非确有必要，不要调用 execute_shell。",
    "若必须调用 execute_shell，必须始终显式提供 command 参数，不要生成空参数工具调用。",
    opts.customPrompt?.trim() || "",
  ];
  return lines.filter(Boolean).join("\n");
}

async function hasFile(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}
