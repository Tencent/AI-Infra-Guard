import type { OpenClawConfig } from "openclaw/plugin-sdk/core";
import {
  buildCompletedHeader,
  buildErrorText,
  buildStuckText,
  collectResultImages,
  formatResult,
  type FormatResultOpts,
} from "./poll.js";
import type { AigMonitorSnapshot, AigTaskNotifier } from "./background-monitor.js";
import { deliverSessionNotification } from "./session-delivery.js";

type MonitorLogger = {
  info?: (message: string) => void;
  warn?: (message: string) => void;
  error?: (message: string) => void;
};

export function createAigTaskNotifier(params: {
  config: OpenClawConfig;
  logger: MonitorLogger;
  formatResultOpts?: FormatResultOpts;
}): AigTaskNotifier {
  const { config, logger, formatResultOpts } = params;

  return {
    async notify(snapshot: AigMonitorSnapshot): Promise<void> {
      if (!snapshot.sessionKey) return;

      const text = buildNotificationText(snapshot, formatResultOpts);
      const mediaUrls =
        snapshot.state === "completed"
          ? collectResultImages(snapshot.result, formatResultOpts)
              .slice(0, 4)
              .map((image) => image.url)
          : undefined;

      try {
        const outcome = await deliverSessionNotification({
          config,
          sessionKey: snapshot.sessionKey,
          agentId: snapshot.agentId,
          text,
          mediaUrls,
          contextKey: `aig:${snapshot.sessionId}:${snapshot.state}`,
        });
        logger.info?.(
          `[aig-scan-plugin] Sent background notification for ${snapshot.sessionId} via ${outcome.via}`,
        );
      } catch (err) {
        logger.warn?.(
          `[aig-scan-plugin] Failed to send background notification for ${snapshot.sessionId}: ${String(err)}`,
        );
      }
    },
  };
}

function buildNotificationText(
  snapshot: AigMonitorSnapshot,
  formatResultOpts?: FormatResultOpts,
): string {
  const elapsedMs = Math.max(0, Date.now() - snapshot.startedAt);
  const prefix = "🔔 AIG 后台监控提醒";

  if (snapshot.state === "completed") {
    return [
      prefix,
      buildCompletedHeader({
        title: snapshot.title,
        sessionId: snapshot.sessionId,
        elapsedMs,
      }),
      "📊 扫描结果",
      formatResult(snapshot.result, formatResultOpts),
    ].join("\n");
  }

  if (snapshot.state === "failed" && snapshot.status) {
    return [prefix, buildErrorText({
      title: snapshot.title,
      sessionId: snapshot.sessionId,
      elapsedMs,
      status: snapshot.status,
    })].join("\n");
  }

  return [prefix, buildStuckText({
    title: snapshot.title,
    sessionId: snapshot.sessionId,
    elapsedMs,
    reason: snapshot.reason ?? "AIG 任务长时间未结束。",
  })].join("\n");
}
