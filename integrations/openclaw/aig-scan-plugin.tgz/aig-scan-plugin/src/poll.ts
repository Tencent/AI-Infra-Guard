/**
 * Shared polling logic and result formatters for all AIG scan tools.
 *
 * Two-phase scan flow
 * ───────────────────
 * Phase 1  (scan tool):     submit task → short foreground poll
 *   • Finishes quickly  → return full formatted results directly
 *   • Still running     → return a background-running handoff with session_id
 *
 * Phase 2  (result check tool): optional short follow-up poll
 *   • Finishes quickly  → return full formatted results directly
 *   • Still running     → return a clear hand-off message with session_id
 */

import type { AigClient } from "./client.js";
import type { AigTaskStatusData } from "./types.js";

// ─── Timing constants ─────────────────────────────────────────────────────────

export type AigPollingOptions = {
  submitPollIntervalMs: number;
  submitMaxWaitMs: number;
  monitorPollIntervalMs: number;
  monitorMaxWaitMs: number;
};

// Phase 1 (submit): short wait so the tool feels immediately responsive.
// Phase 2 (result check): wait up to 3 min to keep the conversation unblocked.
//   If still running, background monitor continues silently for another 30+ min.
//   User can ask again any time ("查看结果") to check the cache.
export const DEFAULT_POLLING_OPTIONS: AigPollingOptions = {
  submitPollIntervalMs: 2_000,
  submitMaxWaitMs:      10_000,
  monitorPollIntervalMs: 5_000,
  monitorMaxWaitMs:     3 * 60 * 1000,   // 3 minutes — unblocks conversation sooner
};

function sanitizeMs(value: unknown, fallback: number): number {
  if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
  const rounded = Math.round(value);
  return rounded >= 250 ? rounded : fallback;
}

export function resolvePollingOptions(
  input: Partial<AigPollingOptions> | undefined,
): AigPollingOptions {
  return {
    submitPollIntervalMs: sanitizeMs(
      input?.submitPollIntervalMs,
      DEFAULT_POLLING_OPTIONS.submitPollIntervalMs,
    ),
    submitMaxWaitMs: sanitizeMs(input?.submitMaxWaitMs, DEFAULT_POLLING_OPTIONS.submitMaxWaitMs),
    monitorPollIntervalMs: sanitizeMs(
      input?.monitorPollIntervalMs,
      DEFAULT_POLLING_OPTIONS.monitorPollIntervalMs,
    ),
    monitorMaxWaitMs: sanitizeMs(
      input?.monitorMaxWaitMs,
      DEFAULT_POLLING_OPTIONS.monitorMaxWaitMs,
    ),
  };
}

// ─── Status helpers ───────────────────────────────────────────────────────────

export const STATUS_EMOJI: Record<string, string> = {
  todo: "⏳", doing: "🔄", done: "✅", error: "❌", terminated: "🛑",
  pending: "⏳", running: "🔄", completed: "✅", failed: "❌",
};

export function isCompleted(status: string): boolean {
  return status === "done" || status === "completed";
}

export function isInProgress(status: string): boolean {
  return (
    status === "todo" || status === "doing" ||
    status === "pending" || status === "running"
  );
}

export function isFailed(status: string): boolean {
  return (
    status === "error" || status === "failed" || status === "terminated"
  );
}

export function detectStuckReason(status: Pick<AigTaskStatusData, "status" | "log">): string | null {
  if (isFailed(status.status)) return null;
  if (typeof status.log !== "string" || !status.log) return null;

  const matches = [...status.log.matchAll(/Error:\s*([^\n`]+)/g)]
    .map((match) => match[1]?.trim())
    .filter((value): value is string => Boolean(value));
  if (matches.length === 0) return null;

  const counts = new Map<string, number>();
  for (const item of matches) {
    counts.set(item, (counts.get(item) ?? 0) + 1);
  }

  let topMessage = "";
  let topCount = 0;
  for (const [message, count] of counts) {
    if (count > topCount) {
      topMessage = message;
      topCount = count;
    }
  }

  if (topCount < 3) return null;

  if (topMessage.includes("execute_shell() missing 1 required positional argument: 'command'")) {
    return "AIG 后台重复出现工具调用错误：execute_shell 缺少 command 参数，任务大概率已卡住。";
  }

  return `AIG 后台重复出现同一错误 ${topCount} 次：${topMessage}`;
}

// ─── Polling ──────────────────────────────────────────────────────────────────

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export type PollOutcome =
  | { outcome: "completed"; status: AigTaskStatusData; result: unknown; elapsedMs: number }
  | { outcome: "failed";    status: AigTaskStatusData; elapsedMs: number }
  | { outcome: "timeout";   status: AigTaskStatusData; sessionId: string; elapsedMs: number };

/**
 * Poll an AIG task until done, failed, or timed out.
 * First check is immediate (task may finish within seconds for small targets).
 */
export async function pollUntilDone(
  client: AigClient,
  sessionId: string,
  opts: { intervalMs?: number; maxWaitMs?: number } = {},
): Promise<PollOutcome> {
  const intervalMs = opts.intervalMs ?? DEFAULT_POLLING_OPTIONS.monitorPollIntervalMs;
  const maxWaitMs  = opts.maxWaitMs  ?? DEFAULT_POLLING_OPTIONS.monitorMaxWaitMs;
  const startTime  = Date.now();

  let status = await client.getTaskStatus(sessionId);

  while (true) {
    const elapsedMs = Date.now() - startTime;

    if (isCompleted(status.status)) {
      const result = await client.getTaskResult(sessionId);
      return { outcome: "completed", status, result, elapsedMs };
    }
    if (isFailed(status.status)) {
      return { outcome: "failed", status, elapsedMs };
    }
    if (elapsedMs >= maxWaitMs) {
      return { outcome: "timeout", status, sessionId, elapsedMs };
    }

    await sleep(intervalMs);
    status = await client.getTaskStatus(sessionId);
  }
}

// ─── Output helpers ───────────────────────────────────────────────────────────

/** Format elapsed milliseconds as "Xm Ys" or "Xs". */
export function fmtDuration(ms: number): string {
  const totalSec = Math.round(ms / 1000);
  if (totalSec < 60) return `${totalSec}s`;
  const min = Math.floor(totalSec / 60);
  const sec = totalSec % 60;
  return sec > 0 ? `${min}m ${sec}s` : `${min}m`;
}

const DIV = "─".repeat(44);

/** Build the standardised "still running" response used by all scan tools. */
export function buildStillRunningText(opts: {
  title: string;
  sessionId: string;
  elapsedMs: number;
  currentStatus: string;
  extraLines?: string[];
  etaHint?: string;
}): string {
  const lines = [
    `✅ ${opts.title} — 任务已提交`,
    DIV,
    ...(opts.extraLines ?? []),
    `🔑 Session ID：${opts.sessionId}`,
    `📡 当前状态：${opts.currentStatus.toUpperCase()}（AIG 后台执行中）`,
    `⏱  前台已等待：${fmtDuration(opts.elapsedMs)}`,
    opts.etaHint ? `🕒 预计还需：${opts.etaHint}` : `🕒 通常还需要几分钟，请稍候。`,
    DIV,
    `AIG 已转入后台继续分析。我会继续跟进一次结果；如果还没完成，你之后随时说“查看结果”即可继续查询。`,
  ];
  return lines.join("\n");
}

/** Build the standardised "scan error" response. */
export function buildErrorText(opts: {
  title: string;
  sessionId: string;
  elapsedMs: number;
  status: AigTaskStatusData;
}): string {
  const lines = [
    `❌ ${opts.title}`,
    DIV,
    `🔑 Session ID：${opts.sessionId}`,
    `📡 状态：${opts.status.status.toUpperCase()}`,
    `⏱  耗时：${fmtDuration(opts.elapsedMs)}`,
  ];
  if (opts.status.log) {
    lines.push(DIV, `📋 错误日志：`, opts.status.log);
  }
  lines.push(DIV, `💡 可重新提交扫描任务。`);
  return lines.join("\n");
}

/** Build the standardised "timeout" response. */
export function buildTimeoutText(opts: {
  title: string;
  sessionId: string;
  elapsedMs: number;
  extraLines?: string[];
}): string {
  return [
    `⏳ ${opts.title} — 仍在后台执行`,
    DIV,
    ...(opts.extraLines ?? []),
    `🔑 Session ID：${opts.sessionId}`,
    `⏱  本次前台跟进：${fmtDuration(opts.elapsedMs)}`,
    DIV,
    `AIG 后台任务还在继续跑。稍后直接说“查看刚才的扫描结果”，或提供 Session ID 继续查询即可。`,
  ].join("\n");
}

export function buildStuckText(opts: {
  title: string;
  sessionId: string;
  elapsedMs: number;
  reason: string;
  extraLines?: string[];
}): string {
  return [
    `⚠️ ${opts.title} — 任务疑似卡住`,
    DIV,
    ...(opts.extraLines ?? []),
    `🔑 Session ID：${opts.sessionId}`,
    `⏱  已观察：${fmtDuration(opts.elapsedMs)}`,
    `📌 诊断：${opts.reason}`,
    DIV,
    `💡 建议：优先改用可用模型重试；若是 GitHub 上的 AI 工具 / Skills 源码，建议改用本地压缩包上传模式重新扫描。`,
  ].join("\n");
}

/** Build the standardised completed report header. */
export function buildCompletedHeader(opts: {
  title: string;
  sessionId: string;
  elapsedMs: number;
  extraLines?: string[];
}): string {
  return [
    `✅ ${opts.title} — 扫描完成`,
    DIV,
    ...(opts.extraLines ?? []),
    `🔑 Session ID：${opts.sessionId}`,
    `⏱  耗时：${fmtDuration(opts.elapsedMs)}`,
    DIV,
  ].join("\n");
}

// ─── Result formatters ────────────────────────────────────────────────────────

/**
 * Dispatch to the correct formatter based on result structure.
 *
 * All task types share the outer envelope:
 *   { id, result: <task-data>, timestamp, type: "resultUpdate" }
 *
 * ── ai_infra_scan ────────────────────────────────────────────────────────────
 *   result.result: { results: TargetResult[], score, total }
 *   VulnInfo.severity: "Critical" | "High" | "Medium" | "Low" | "Info"
 *
 * ── mcp_scan (AI tool / skills scan, supports MCP / Skills) ─────────────────
 *   result.result: { readme?: string, results?: Issue[], issues?: Issue[], report?: Issue[] }
 *   Issue.level: "high" | "medium" | "low"  (lowercase)
 *
 * ── agent_scan ────────────────────────────────────────────────────────────────
 *   result.result: {
 *     vulnerable_tests?: number,
 *     total?: number,
 *     score?: number,
 *     results?: AgentFinding[],
 *     readme?/overview?/summary?
 *   }
 *   AgentFinding fields vary by engine version, so the formatter uses tolerant heuristics.
 *
 * ── model_redteam_report ──────────────────────────────────────────────────────
 *   result.result: {
 *     content: Array<{ results: PromptResults[], total, score, jailbreak, attachment, modelName }>,
 *     msgType, status, timestamp
 *   }
 *   PromptResults.status: "jailbroken" | "safe"
 *   Note: per-model data is wrapped inside content[]; must be unwrapped before dispatch.
 */
export type FormatResultOpts = {
  /** AIG server base URL (e.g. "http://localhost:8088").
   *  Used to build absolute screenshot URLs for ai_infra_scan results. */
  serverUrl?: string;
};

export type ResultImageRef = {
  url: string;
  alt: string;
};

export function formatResult(result: unknown, opts?: FormatResultOpts): string {
  if (!result || typeof result !== "object") return String(result);

  const outer = result as Record<string, unknown>;
  const inner =
    outer.result && typeof outer.result === "object"
      ? (outer.result as Record<string, unknown>)
      : outer;

  // model_redteam_report: per-model results are wrapped in content[]
  // e.g. inner = { content: [{score, total, jailbreak, attachment, results[], modelName}], msgType, status, timestamp }
  if (Array.isArray(inner.content) && inner.content.length > 0) {
    const first = inner.content[0] as Record<string, unknown>;
    if (typeof first.jailbreak === "number" || typeof first.modelName === "string") {
      if (inner.content.length === 1) {
        return formatRedTeamResult(first);
      }
      return (inner.content as Record<string, unknown>[])
        .map((item, i) => {
          const name = typeof item.modelName === "string" ? item.modelName : `Model ${i + 1}`;
          return `### ${name}\n${formatRedTeamResult(item)}`;
        })
        .join("\n\n");
    }
  }

  if (Array.isArray(inner.issues) || Array.isArray(inner.report)) {
    return formatMcpScanResult(inner);
  }

  const firstResult =
    Array.isArray(inner.results) && inner.results.length > 0
      ? (inner.results[0] as Record<string, unknown>)
      : null;
  if (looksLikeAgentScanResult(inner, firstResult)) {
    return formatAgentScanResult(inner);
  }
  if (typeof inner.jailbreak === "number" || (firstResult && "modelName" in firstResult)) {
    return formatRedTeamResult(inner);
  }

  if (hasMcpOverview(inner) || getMcpFindings(inner).length > 0) {
    return formatMcpScanResult(inner);
  }

  return formatInfraResult(inner, opts);
}

export function collectResultImages(result: unknown, opts?: FormatResultOpts): ResultImageRef[] {
  if (!result || typeof result !== "object") return [];

  const outer = result as Record<string, unknown>;
  const inner =
    outer.result && typeof outer.result === "object"
      ? (outer.result as Record<string, unknown>)
      : outer;

  const out: ResultImageRef[] = [];
  const seen = new Set<string>();
  const pushImage = (rawUrl: unknown, alt: string) => {
    const url = normalizeImageUrl(rawUrl, opts);
    if (!url || seen.has(url)) return;
    seen.add(url);
    out.push({ url, alt });
  };

  // model_redteam_report wraps per-model data in content[]; collect screenshots from each item's results
  const resultSources: Record<string, unknown>[] =
    Array.isArray(inner.content) && inner.content.length > 0 &&
    typeof (inner.content[0] as Record<string, unknown>).jailbreak === "number"
      ? (inner.content as Record<string, unknown>[])
      : [inner];

  for (const src of resultSources) {
    if (Array.isArray(src.results)) {
      for (const item of src.results) {
        if (typeof item !== "object" || item === null) continue;
        const obj = item as Record<string, unknown>;
        if (typeof obj.screenshot === "string" && obj.screenshot.trim()) {
          const targetLabel = compactTargetLabel(obj.target_url);
          pushImage(obj.screenshot, `${targetLabel} 页面截图`);
        }
      }
    }
  }

  collectNestedImageUrls(inner, opts, seen, out);
  return out;
}

// ── ai_infra_scan ─────────────────────────────────────────────────────────────

function formatInfraResult(inner: Record<string, unknown>, opts?: FormatResultOpts): string {
  const score = typeof inner.score === "number" ? inner.score : null;
  const total = typeof inner.total === "number" ? inner.total : null;
  const targets = Array.isArray(inner.results) ? inner.results : [];

  const out: string[] = [];
  if (total !== null) {
    out.push(
      total === 0
        ? `✅ 未发现漏洞  安全评分：${score ?? "N/A"}/100`
        : `⚠️ 共发现 ${total} 个漏洞  安全评分：${score ?? "N/A"}/100`,
    );
  } else if (score !== null) {
    out.push(`📊 安全评分：${score}/100`);
  }

  if (targets.length > 0) {
    out.push(`🎯 扫描目标：${targets.length} 个`);
  }

  const severityCounts: Record<string, number> = {
    Critical: 0,
    High: 0,
    Medium: 0,
    Low: 0,
    Info: 0,
  };
  const targetSummaries: string[] = [];
  const highlightItems: string[] = [];
  let hiddenHighlights = 0;

  for (const target of targets) {
    if (typeof target !== "object" || target === null) continue;
    const targetObj = target as Record<string, unknown>;
    const targetLabel = compactTargetLabel(targetObj.target_url);
    const summary =
      typeof targetObj.summary === "string" && targetObj.summary.trim()
        ? clipText(targetObj.summary, 90)
        : "";
    if (summary) {
      targetSummaries.push(`${targetLabel}：${summary}`);
    }

    // ── Screenshot (only present when analysis_model is provided) ────────────
    // AIG stores a relative path like "/api/v1/images/{fileUrl}"; prepend server URL.
    const vulns = Array.isArray(targetObj.vulnerabilities)
      ? targetObj.vulnerabilities
      : [];
    for (const vuln of vulns) {
      if (typeof vuln !== "object" || vuln === null) continue;
      const vulnObj = vuln as Record<string, unknown>;
      const severity = normalizeInfraSeverity(vulnObj.severity);
      severityCounts[severity] += 1;

      if (highlightItems.length >= 5) {
        hiddenHighlights += 1;
        continue;
      }

      const name = String(vulnObj.name ?? "Unknown");
      const vulnSummary =
        typeof vulnObj.summary === "string" && vulnObj.summary.trim()
          ? `：${clipText(vulnObj.summary, 70)}`
          : "";
      highlightItems.push(`[${severity}] ${targetLabel} - ${name}${vulnSummary}`);
    }
  }

  const severitySummary = Object.entries(severityCounts)
    .filter(([, count]) => count > 0)
    .map(([severity, count]) => `${severity} ${count}`)
    .join("，");
  if (severitySummary) {
    out.push(`📈 风险分布：${severitySummary}`);
  }

  const summaryItems = dedupeItems(targetSummaries).slice(0, 3);
  const highlights = dedupeItems(highlightItems);
  if (summaryItems.length > 0 || highlights.length > 0) {
    out.push("", `📝 聊天摘要`);
    for (const item of summaryItems) {
      out.push(`- ${item}`);
    }
    for (const item of highlights) {
      out.push(`- ${item}`);
    }
    if (hiddenHighlights > 0) {
      out.push(`- 其余 ${hiddenHighlights} 个漏洞未在聊天窗口展开`);
    }
  }

  return finalize(out);
}

// ── mcp_scan ──────────────────────────────────────────────────────────────────

function formatMcpScanResult(inner: Record<string, unknown>): string {
  const out: string[] = [];
  const score = typeof inner.score === "number" ? inner.score : null;
  const llm = typeof inner.llm === "string" && inner.llm ? inner.llm : null;
  const language = typeof inner.language === "string" && inner.language ? inner.language : null;
  const readme = typeof inner.readme === "string" ? inner.readme.trim() : "";
  const findings = getMcpFindings(inner);

  if (score !== null) out.push(`📊 安全评分：${score}/100`);
  if (llm) out.push(`🤖 分析模型：${llm}`);
  if (language) out.push(`🧾 代码语言：${language}`);

  if (readme) {
    const summary = summarizeMarkdownForChat(readme, 8);
    out.push("", `📚 项目概览`);
    if (summary.length > 0) {
      for (const item of summary) {
        out.push(`- ${item}`);
      }
    } else {
      out.push(`- 已生成项目概览，但未提取到适合聊天展示的摘要项`);
    }
  }

  out.push("", ...formatMcpRiskSection(findings));
  return finalize(out);
}

function formatMcpRiskSection(findings: Record<string, unknown>[]): string[] {
  const LEVEL_EMOJI:  Record<string, string> = { high: "🟠", medium: "🟡", low: "🔵" };
  const LEVEL_LABEL:  Record<string, string> = { high: "High", medium: "Medium", low: "Low" };

  const out: string[] = [`🛡️ 安全风险`];
  if (findings.length === 0) {
    out.push(`✅ 未发现明确的中高危安全风险`);
    return out;
  }

  out.push(`⚠️ 共发现 ${findings.length} 个安全问题`);

  const byLevel: Record<string, string[]> = {
    high: [], medium: [], low: [], unknown: [],
  };
  for (const issue of findings) {
    const level   = String(issue.level ?? "unknown").toLowerCase();
    const emoji   = LEVEL_EMOJI[level] ?? "•";
    const title   = String(issue.title ?? "Untitled");
    const desc    = issue.description ? `\n     ${issue.description}` : issue.desc ? `\n     ${issue.desc}` : "";
    const suggest = issue.suggestion  ? `\n     🔧 ${issue.suggestion}` : "";
    const risk    = issue.risk_type   ? ` [${issue.risk_type}]` : "";
    (byLevel[level] ?? byLevel["unknown"]!).push(
      `  ${emoji} ${title}${risk}${desc}${suggest}`,
    );
  }

  for (const level of ["high", "medium", "low", "unknown"]) {
    const items = byLevel[level]!;
    if (items.length > 0) {
      const emoji = LEVEL_EMOJI[level] ?? "•";
      const label = LEVEL_LABEL[level] ?? level;
      out.push(``, `${emoji} ${label} (${items.length})`);
      out.push(...items);
    }
  }

  return out;
}

function summarizeMarkdownForChat(markdown: string, maxItems: number): string[] {
  const cleaned = markdown
    .replace(/```[\s\S]*?```/g, "")
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .filter((line) => !line.startsWith("|"))
    .filter((line) => !/^[-:|]{3,}$/.test(line));

  const out: string[] = [];
  const seen = new Set<string>();
  for (const line of cleaned) {
    let item = "";

    if (line.startsWith("# ")) {
      item = line.slice(2).trim();
    } else if (line.startsWith("- ")) {
      item = line.slice(2).trim();
    } else if (line.startsWith("## ") || line.startsWith("### ")) {
      continue;
    } else if (out.length < 2 && line.length <= 120) {
      item = line;
    }

    if (!item) continue;
    item = item.replace(/\*\*/g, "").replace(/`/g, "");
    if (item.length > 140) item = item.slice(0, 140) + "…";
    if (seen.has(item)) continue;

    seen.add(item);
    out.push(item);
    if (out.length >= maxItems) break;
  }

  return out;
}

function hasMcpOverview(inner: Record<string, unknown>): boolean {
  return typeof inner.readme === "string" && inner.readme.trim().length > 0;
}

function getMcpFindings(inner: Record<string, unknown>): Record<string, unknown>[] {
  const legacyIssues = Array.isArray(inner.issues) ? inner.issues : [];
  const legacyReport = Array.isArray(inner.report) ? inner.report : [];
  const results = Array.isArray(inner.results) ? inner.results : [];

  const seen = new Set<string>();
  const out: Record<string, unknown>[] = [];
  for (const item of [...legacyIssues, ...legacyReport, ...results]) {
    if (typeof item !== "object" || item === null) continue;
    const obj = item as Record<string, unknown>;
    if (!looksLikeMcpFinding(obj)) continue;
    const key = [
      String(obj.title ?? ""),
      String(obj.description ?? obj.desc ?? ""),
      String(obj.risk_type ?? ""),
      String(obj.level ?? ""),
    ].join("|");
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(obj);
  }
  return out;
}

function looksLikeMcpFinding(item: Record<string, unknown>): boolean {
  return (
    typeof item.level === "string" ||
    typeof item.risk_type === "string" ||
    typeof item.suggestion === "string"
  );
}

// ── agent_scan ───────────────────────────────────────────────────────────────

function formatAgentScanResult(inner: Record<string, unknown>): string {
  const score = typeof inner.score === "number" ? inner.score : null;
  const total =
    typeof inner.vulnerable_tests === "number"
      ? inner.vulnerable_tests
      : typeof inner.total === "number"
        ? inner.total
        : null;
  const findings = getAgentFindings(inner);

  const out: string[] = [];
  if (total !== null) {
    out.push(
      total === 0
        ? `✅ 未发现明确风险  安全评分：${score ?? "N/A"}/100`
        : `⚠️ 共发现 ${total} 个风险项  安全评分：${score ?? "N/A"}/100`,
    );
  } else if (score !== null) {
    out.push(`📊 安全评分：${score}/100`);
  }

  const overviewItems = summarizeAgentOverview(inner).slice(0, 6);
  if (overviewItems.length > 0) {
    out.push("", `📚 项目概览`);
    for (const item of overviewItems) {
      out.push(`- ${item}`);
    }
  }

  out.push("", ...formatAgentRiskSection(findings, total));
  return finalize(out);
}

function formatAgentRiskSection(findings: Record<string, unknown>[], total: number | null): string[] {
  const out: string[] = [`🛡️ 安全风险`];
  if (total === 0 || findings.length === 0) {
    out.push(`✅ 未发现明确的中高危 Agent 风险`);
    return out;
  }

  const severityCounts: Record<string, number> = {
    Critical: 0,
    High: 0,
    Medium: 0,
    Low: 0,
    Info: 0,
  };
  const highlights: string[] = [];
  let hiddenCount = 0;

  for (const finding of findings) {
    const severity = normalizeAgentSeverity(finding.severity ?? finding.level);
    severityCounts[severity] += 1;

    if (highlights.length >= 5) {
      hiddenCount += 1;
      continue;
    }

    const title =
      firstString(
        finding.title,
        finding.name,
        finding.vulnerability,
        finding.risk_type,
        finding.category,
      ) ?? "未命名风险";
    const category = firstString(finding.category, finding.risk_type, finding.owasp_id);
    const summary = firstString(
      finding.summary,
      finding.reason,
      finding.description,
      finding.desc,
      finding.impact,
    );
    const fix = firstString(
      finding.suggestion,
      finding.remediation,
      finding.fix_recommendation,
      finding.recommendation,
    );

    let line = `- [${severity}] ${title}`;
    if (category) line += ` [${category}]`;
    if (summary) line += `：${clipText(summary, 80)}`;
    if (fix) line += ` / 修复：${clipText(fix, 50)}`;
    highlights.push(line);
  }

  const severitySummary = Object.entries(severityCounts)
    .filter(([, count]) => count > 0)
    .map(([severity, count]) => `${severity} ${count}`)
    .join("，");
  if (severitySummary) {
    out.push(`📈 风险分布：${severitySummary}`);
  }

  out.push(`📝 聊天摘要`);
  out.push(...highlights);
  if (hiddenCount > 0) {
    out.push(`- 其余 ${hiddenCount} 个风险项未在聊天窗口展开`);
  }

  return out;
}

function summarizeAgentOverview(inner: Record<string, unknown>): string[] {
  const directText = firstString(
    inner.readme,
    inner.overview,
    inner.summary,
    inner.project_overview,
    inner.info,
  );
  if (directText) {
    return summarizeMarkdownForChat(directText, 8);
  }

  const info = inner.project_info;
  if (typeof info === "object" && info !== null) {
    return Object.entries(info as Record<string, unknown>)
      .map(([key, value]) => `${key}: ${clipText(String(value), 80)}`)
      .slice(0, 6);
  }

  return [];
}

function looksLikeAgentScanResult(
  inner: Record<string, unknown>,
  firstResult: Record<string, unknown> | null,
): boolean {
  if (typeof inner.vulnerable_tests === "number") return true;
  if (typeof inner.agent_id === "string" || typeof inner.agent_name === "string") return true;
  if (!firstResult) return false;

  const hasDirectRiskFields =
    typeof firstResult.severity === "string" ||
    typeof firstResult.level === "string" ||
    typeof firstResult.vulnerability === "string" ||
    typeof firstResult.risk_type === "string" ||
    typeof firstResult.category === "string";
  const hasAgentEvidence =
    typeof firstResult.input === "string" ||
    typeof firstResult.output === "string" ||
    typeof firstResult.remediation === "string" ||
    typeof firstResult.fix_recommendation === "string";

  return hasDirectRiskFields && hasAgentEvidence;
}

function getAgentFindings(inner: Record<string, unknown>): Record<string, unknown>[] {
  const results = Array.isArray(inner.results) ? inner.results : [];
  const out: Record<string, unknown>[] = [];

  for (const item of results) {
    if (typeof item !== "object" || item === null) continue;
    const obj = item as Record<string, unknown>;
    if (looksLikeAgentFinding(obj)) {
      out.push(obj);
      continue;
    }
    if (Array.isArray(obj.vulnerabilities)) {
      for (const nested of obj.vulnerabilities) {
        if (typeof nested !== "object" || nested === null) continue;
        const finding = nested as Record<string, unknown>;
        if (looksLikeAgentFinding(finding)) {
          out.push(finding);
        }
      }
    }
  }

  return dedupeObjects(out, (item) =>
    [
      firstString(item.title, item.name, item.vulnerability, item.risk_type, item.category) ?? "",
      firstString(item.description, item.desc, item.reason, item.summary) ?? "",
      firstString(item.severity, item.level) ?? "",
    ].join("|"),
  );
}

function looksLikeAgentFinding(item: Record<string, unknown>): boolean {
  return (
    typeof item.severity === "string" ||
    typeof item.level === "string" ||
    typeof item.vulnerability === "string" ||
    typeof item.risk_type === "string" ||
    typeof item.category === "string"
  );
}

// ── model_redteam_report ──────────────────────────────────────────────────────

function formatRedTeamResult(inner: Record<string, unknown>): string {
  const score = typeof inner.score === "number" ? inner.score : null;
  const total = typeof inner.total === "number" ? inner.total : null;
  const baseTotal = typeof inner.baseTotal === "number" ? inner.baseTotal : null;
  const errored = typeof inner.errored === "number" ? inner.errored : null;
  const jailCnt = typeof inner.jailbreak === "number" ? inner.jailbreak : null;
  const attach = typeof inner.attachment === "string" && inner.attachment
    ? inner.attachment : null;
  const results = Array.isArray(inner.results) ? inner.results : [];

  const out: string[] = [];

  if (jailCnt !== null && total !== null) {
    out.push(
      jailCnt === 0
        ? `✅  越狱防护通过   0/${total} 条攻击成功   评分：${score ?? "N/A"}/100`
        : `🚨  越狱防护失败   ${jailCnt}/${total} 条攻击成功   评分：${score ?? "N/A"}/100`,
    );
  } else if (score !== null) {
    out.push(`📊  红队评分：${score}/100`);
  }

  if (baseTotal !== null || errored !== null) {
    const expected = baseTotal ?? total;
    const parts = [];
    if (expected !== null && total !== null) parts.push(`已评估：${total}/${expected} 条`);
    if (errored !== null && errored > 0) parts.push(`评估失败：${errored} 条`);
    if (parts.length > 0) out.push(`🧪  ${parts.join("   ")}`);
  }

  if (attach) out.push(`📎  完整报告：${attach}`);

  const jailCases = results.filter((r) => {
    if (typeof r !== "object" || r === null) return false;
    const status = (r as Record<string, unknown>).status;
    return typeof status === "string" && ["jailbreak", "jailbroken"].includes(status.toLowerCase());
  });

  if (jailCases.length > 0) {
    out.push(``, `📝 聊天摘要（越狱成功样本）`);
    for (const r of jailCases.slice(0, 5)) {
      if (typeof r !== "object" || r === null) continue;
      const rObj = r as Record<string, unknown>;
      const model = typeof rObj.modelName === "string" && rObj.modelName
        ? rObj.modelName
        : "unknown-model";
      const method = typeof rObj.attackMethod === "string" && rObj.attackMethod
        ? rObj.attackMethod
        : "unknown";
      const vulnerability =
        typeof rObj.vulnerability === "string" && rObj.vulnerability
          ? ` / ${rObj.vulnerability}`
          : "";
      const reason =
        typeof rObj.reason === "string" && rObj.reason.trim()
          ? ` / ${clipText(rObj.reason, 60)}`
          : "";
      const inp =
        typeof rObj.input === "string" && rObj.input.trim()
          ? ` / 攻击：${clipText(rObj.input, 50)}`
          : "";
      const outp =
        typeof rObj.output === "string" && rObj.output.trim()
          ? ` / 回复：${clipText(rObj.output, 50)}`
          : "";
      out.push(`- [${model}] ${method}${vulnerability}${reason}${inp}${outp}`);
    }
    if (jailCases.length > 5) {
      out.push(`- 其余 ${jailCases.length - 5} 条越狱成功样本未在聊天窗口展开`);
    }
  } else if (total !== null && jailCnt === 0) {
    out.push(``, `✅  在已评估的 ${total} 条攻击中，未发现越狱成功案例`);
    if (results.length > 0 && total > results.length) {
      out.push(`ℹ️  聊天窗口仅保留了 ${results.length} 条样本，不代表完整明细条数`);
    }
  }

  return finalize(out);
}

// ── shared ────────────────────────────────────────────────────────────────────

function finalize(out: string[]): string {
  const text = out.join("\n");
  if (text.length > 5000) return text.slice(0, 5000) + "\n…（内容过长，已截断）";
  return text || "(无结果数据)";
}

function compactTargetLabel(value: unknown): string {
  if (typeof value !== "string" || !value.trim()) return "unknown";
  const raw = value.trim();
  try {
    const parsed = new URL(raw);
    return parsed.host || raw;
  } catch {
    return raw.replace(/^https?:\/\//, "");
  }
}

function clipText(value: string, maxLength: number): string {
  const text = value.replace(/\s+/g, " ").trim();
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + "…";
}

function normalizeInfraSeverity(value: unknown): "Critical" | "High" | "Medium" | "Low" | "Info" {
  const text = String(value ?? "Info").toLowerCase();
  if (text === "critical") return "Critical";
  if (text === "high") return "High";
  if (text === "medium") return "Medium";
  if (text === "low") return "Low";
  return "Info";
}

function dedupeItems(items: string[]): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const item of items) {
    if (!item || seen.has(item)) continue;
    seen.add(item);
    out.push(item);
  }
  return out;
}

function dedupeObjects<T>(items: T[], keyFn: (item: T) => string): T[] {
  const out: T[] = [];
  const seen = new Set<string>();
  for (const item of items) {
    const key = keyFn(item);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}

function firstString(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }
  return null;
}

function collectNestedImageUrls(
  value: unknown,
  opts: FormatResultOpts | undefined,
  seen: Set<string>,
  out: ResultImageRef[],
  depth = 0,
): void {
  if (depth > 6 || value == null) return;

  if (typeof value === "string") {
    const url = normalizeImageUrl(value, opts);
    if (!url || seen.has(url)) return;
    seen.add(url);
    out.push({ url, alt: "AIG 结果图片" });
    return;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      collectNestedImageUrls(item, opts, seen, out, depth + 1);
    }
    return;
  }

  if (typeof value !== "object") return;

  for (const [key, nested] of Object.entries(value as Record<string, unknown>)) {
    if (key === "screenshot") {
      continue;
    }
    collectNestedImageUrls(nested, opts, seen, out, depth + 1);
  }
}

function normalizeImageUrl(value: unknown, opts?: FormatResultOpts): string | null {
  if (typeof value !== "string") return null;
  const raw = value.trim();
  if (!raw) return null;

  if (!isImageLikePath(raw)) return null;

  if (/^https?:\/\//i.test(raw)) {
    return raw;
  }

  if (raw.startsWith("/")) {
    const base = opts?.serverUrl?.replace(/\/$/, "");
    return base ? `${base}${raw}` : null;
  }

  return null;
}

function isImageLikePath(value: string): boolean {
  if (value.includes("/api/v1/images/")) {
    return true;
  }
  return /\.(png|jpe?g|gif|webp|bmp|svg)(?:[?#].*)?$/i.test(value);
}

function normalizeAgentSeverity(value: unknown): "Critical" | "High" | "Medium" | "Low" | "Info" {
  const text = String(value ?? "Info").trim().toLowerCase();
  if (text === "critical" || text === "严重" || text === "high-risk") return "Critical";
  if (text === "high" || text === "高危" || text === "high risk") return "High";
  if (text === "medium" || text === "中危" || text === "medium risk") return "Medium";
  if (text === "low" || text === "低危" || text === "low risk") return "Low";
  return "Info";
}
