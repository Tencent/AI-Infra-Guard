import type { AigClient } from "./client.js";
import { collectResultImages } from "./poll.js";

type TextBlock = {
  type: "text";
  text: string;
};

export type AigToolContentBlock = TextBlock;

/** Wrap content blocks into the AgentToolResult shape required by the plugin SDK. */
export function toolResult(content: AigToolContentBlock[]): { content: never[]; details: undefined } {
  return { content: content as never[], details: undefined };
}

export function buildResultContent(
  reportText: string,
  result: unknown,
  client: AigClient,
): AigToolContentBlock[] {
  const images = collectResultImages(result, { serverUrl: client.serverUrl }).slice(0, 4);
  // https:// images embed inline (CSP allows); http:// images degrade to clickable links.
  const imageMarkdown = images
    .map((image, index) =>
      image.url.startsWith("https://")
        ? `![AIG screenshot ${index + 1}](${image.url})`
        : `[📸 查看截图 ${index + 1}](${image.url})`,
    )
    .join("\n");
  const text = images.length > 0 ? `${reportText}\n\n${imageMarkdown}` : reportText;

  return [{ type: "text", text }];
}
