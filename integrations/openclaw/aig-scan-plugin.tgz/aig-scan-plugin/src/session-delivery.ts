import type { ReplyPayload } from "../../../src/auto-reply/types.js";
import { resolveSessionAgentId } from "../../../src/agents/agent-scope.js";
import {
  loadSessionStore,
  resolveDefaultSessionStorePath,
  resolveSessionStoreEntry,
} from "../../../src/config/sessions.js";
import type { OpenClawConfig } from "../../../src/config/types.js";
import { buildOutboundSessionContext } from "../../../src/infra/outbound/session-context.js";
import { deliverOutboundPayloads } from "../../../src/infra/outbound/deliver-runtime.js";
import { resolveSessionDeliveryTarget } from "../../../src/infra/outbound/targets.js";
import { enqueueSystemEvent } from "../../../src/infra/system-events.js";

export type SessionDeliveryParams = {
  config: OpenClawConfig;
  sessionKey: string;
  agentId?: string;
  text: string;
  mediaUrls?: string[];
  contextKey?: string;
};

export async function deliverSessionNotification(
  params: SessionDeliveryParams,
): Promise<{ via: "external" | "system-event"; channel?: string; to?: string; reason?: string }> {
  const sessionKey = params.sessionKey.trim();
  if (!sessionKey) {
    throw new Error("sessionKey is required");
  }

  const agentId =
    params.agentId?.trim() || resolveSessionAgentId({ sessionKey, config: params.config });
  const storePath = resolveDefaultSessionStorePath(agentId);
  const store = loadSessionStore(storePath);
  const resolved = resolveSessionStoreEntry({ store, sessionKey });
  const target = resolveSessionDeliveryTarget({
    entry: resolved.existing,
    requestedChannel: "last",
  });

  if (!target.channel || !target.to) {
    enqueueSystemEvent(params.text, { sessionKey, contextKey: params.contextKey });
    return { via: "system-event", reason: "no deliverable external target for session" };
  }

  const payloads: ReplyPayload[] = [{
    text: params.text,
    mediaUrls: params.mediaUrls,
  }];

  await deliverOutboundPayloads({
    cfg: params.config,
    channel: target.channel,
    to: target.to,
    accountId: target.accountId,
    threadId: target.threadId,
    payloads,
    session: buildOutboundSessionContext({
      cfg: params.config,
      sessionKey,
      agentId,
    }),
    mirror: {
      sessionKey,
      agentId,
      text: params.text,
      mediaUrls: params.mediaUrls,
    },
    bestEffort: true,
  });

  return {
    via: "external",
    channel: target.channel,
    to: target.to,
  };
}
