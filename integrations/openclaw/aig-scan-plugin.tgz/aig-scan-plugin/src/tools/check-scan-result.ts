import { Type } from "@sinclair/typebox";
import type { AnyAgentTool } from "openclaw/plugin-sdk/core";
import type { AigMonitor } from "../background-monitor.js";
import type { AigClient } from "../client.js";
import {
  type AigPollingOptions,
  buildCompletedHeader,
  buildErrorText,
  buildStuckText,
  buildTimeoutText,
  detectStuckReason,
  formatResult,
  isFailed,
  isInProgress,
  pollUntilDone,
  STATUS_EMOJI,
} from "../poll.js";
import { buildResultContent, toolResult } from "../result-content.js";

type SessionRoute = {
  sessionKey?: string;
  agentId?: string;
};

/**
 * aig_check_scan_result  (Phase 2)
 *
 * Called by the LLM when a scan tool returned a running handoff, or when the user
 * manually wants to query a past session.
 *
 * Behaviour:
 *   • Already done      → returns full formatted results immediately.
 *   • Still running     → does a short foreground follow-up wait, then either returns
 *                         results or a clear "still running in background" hand-off.
 *   • Failed/terminated → returns error + log.
 */
export function createCheckScanResultTool(
  client: AigClient,
  polling: AigPollingOptions,
  monitor: AigMonitor,
  sessionRoute?: SessionRoute,
): AnyAgentTool {
  return {
    name: "aig_check_scan_result",
    label: "AIG 任务状态",
    description:
      "Phase-2 monitor: do a short follow-up check for a running AIG scan and return the result if it finishes soon. " +
      "Call this when a scan tool returned a background-running handoff, or to re-query a historical session. " +
      "session_id is optional: if omitted, the plugin uses the most recently monitored task. " +
      "If the task is still running, returns a background-running hand-off message with the session_id. " +
      "If it returns a complete report, that text is already the final user-facing report. " +
      "The assistant should output that report block directly and completely: do not shorten, paraphrase, rewrite, reorder, or omit any section.",
    parameters: Type.Object({
      session_id: Type.Optional(Type.String({
        description: "The session_id from the scan task. Optional when checking the latest monitored task.",
      })),
    }),

    async execute(_id, params) {
      const sessionId = params.session_id ?? monitor.getLatestSessionId(sessionRoute?.sessionKey);
      if (!sessionId) {
        return toolResult([{
            type: "text" as const,
            text: "❌ 没有可查询的最近任务，请提供 Session ID。",
          }]);
      }

      const cached = monitor.getSnapshot(sessionId);
      if (cached?.state === "completed") {
        const reportText = [
          buildCompletedHeader({
            title: cached.title,
            sessionId,
            elapsedMs: Math.max(0, Date.now() - cached.startedAt),
          }),
          `📊 扫描结果`,
          formatResult(cached.result, { serverUrl: client.serverUrl }),
        ].join("\n");
        return toolResult(buildResultContent(reportText, cached.result, client));
      }

      if (cached?.state === "failed" && cached.status) {
        return toolResult([{
            type: "text" as const,
            text: buildErrorText({
              title: cached.title,
              sessionId,
              elapsedMs: Math.max(0, Date.now() - cached.startedAt),
              status: cached.status,
            }),
          }]);
      }

      if (cached?.state === "stuck") {
        return toolResult([{
            type: "text" as const,
            text: buildStuckText({
              title: cached.title,
              sessionId,
              elapsedMs: Math.max(0, Date.now() - cached.startedAt),
              reason: cached.reason ?? "AIG 后台疑似卡住。",
            }),
          }]);
      }

      // ── Peek at current status ────────────────────────────────────────────
      let peek;
      try {
        peek = await client.getTaskStatus(sessionId);
      } catch (err) {
        return toolResult([{
            type: "text" as const,
            text: `❌ 无法查询任务状态：${String(err)}`,
          }]);
      }

      const stuckReason = detectStuckReason(peek);
      if (stuckReason) {
        return toolResult([{
            type: "text" as const,
            text: buildStuckText({
              title: peek.title ?? cached?.title ?? "AIG 扫描任务",
              sessionId,
              elapsedMs: Math.max(
                0,
                Date.now() - (peek.created_at ?? cached?.startedAt ?? Date.now()),
              ),
              reason: stuckReason,
              extraLines: [
                peek.created_at ? `🕐 开始时间：${new Date(peek.created_at).toLocaleString("zh-CN")}` : "",
              ].filter(Boolean),
            }),
          }]);
      }

      const emoji     = STATUS_EMOJI[peek.status] ?? "❓";
      const startedAt = peek.created_at
        ? new Date(peek.created_at).toLocaleString("zh-CN")
        : "—";
      const title     = peek.title ?? cached?.title ?? "AIG 扫描任务";
      monitor.watch(sessionId, buildMonitorMeta(title, sessionRoute));

      // ── Already done ──────────────────────────────────────────────────────
      if (peek.status === "done" || peek.status === "completed") {
        try {
          const result = await client.getTaskResult(sessionId);
          const reportText = [
            buildCompletedHeader({
              title,
              sessionId,
              elapsedMs: 0,
              extraLines: [`🕐 开始时间：${startedAt}`],
            }),
            `📊 扫描结果`,
            formatResult(result, { serverUrl: client.serverUrl }),
          ].join("\n");
          return toolResult(buildResultContent(reportText, result, client));
        } catch (err) {
          return toolResult([{
              type: "text" as const,
              text: [
                `✅ 任务已完成，但获取结果时出错：${String(err)}`,
                `Session ID：${sessionId}`,
              ].join("\n"),
            }]);
        }
      }

      // ── Failed / terminated ───────────────────────────────────────────────
      if (isFailed(peek.status)) {
        return toolResult([{
            type: "text" as const,
            text: buildErrorText({
              title,
              sessionId,
              elapsedMs: 0,
              status: peek,
            }),
          }]);
      }

      // ── Still running → short foreground follow-up ────────────────────────
      if (isInProgress(peek.status)) {
        const poll = await pollUntilDone(client, sessionId, {
          intervalMs: polling.monitorPollIntervalMs,
          maxWaitMs: polling.monitorMaxWaitMs,
        });

        if (poll.outcome === "timeout") {
          return toolResult([{
              type: "text" as const,
              text: buildTimeoutText({
                title,
                sessionId,
                elapsedMs: poll.elapsedMs,
                extraLines: [
                  `🕐 开始时间：${startedAt}`,
                  `🛰 插件后台监控：运行中`,
                ],
              }),
            }]);
        }

        if (poll.outcome === "failed") {
          return toolResult([{
              type: "text" as const,
              text: buildErrorText({
                title,
                sessionId,
                elapsedMs: poll.elapsedMs,
                status: poll.status,
              }),
            }]);
        }

        // Completed after waiting
        const reportText = [
          buildCompletedHeader({
            title,
            sessionId,
            elapsedMs: poll.elapsedMs,
            extraLines: [`🕐 开始时间：${startedAt}`],
          }),
          `📊 扫描结果`,
          formatResult(poll.result, { serverUrl: client.serverUrl }),
        ].join("\n");
        return toolResult(buildResultContent(reportText, poll.result, client));
      }

      // ── Unknown status ────────────────────────────────────────────────────
      return toolResult([{
          type: "text" as const,
          text: [
            `${emoji} 任务状态：${peek.status}`,
            `Session ID：${sessionId}`,
            peek.title ? `任务：${peek.title}` : "",
          ].filter(Boolean).join("\n"),
        }]);
    },
  };
}

function buildMonitorMeta(title: string, sessionRoute?: SessionRoute) {
  if (!sessionRoute?.sessionKey && !sessionRoute?.agentId) {
    return { title };
  }
  return {
    title,
    sessionKey: sessionRoute.sessionKey,
    agentId: sessionRoute.agentId,
  };
}
