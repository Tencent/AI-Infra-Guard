import { describe, expect, it, vi } from "vitest";
import type { AigMonitor } from "../background-monitor.js";
import { collectResultImages, detectStuckReason, formatResult, resolvePollingOptions } from "../poll.js";
import { buildResultContent } from "../result-content.js";
import { createCheckScanResultTool } from "./check-scan-result.js";
import { createListAgentsTool } from "./list-agents.js";
import { createScanAgentTool } from "./scan-agent.js";
import { createScanInfraTool } from "./scan-infra.js";

function extractText(result: unknown): string {
  const first = (result as { content?: Array<{ text?: string }> } | undefined)?.content?.[0];
  return String(first?.text ?? "");
}

function status(overrides?: Partial<{
  status: string;
  title: string;
  created_at: number;
  updated_at: number;
  log: string;
}>) {
  return {
    session_id: "sess-1",
    status: "doing",
    title: "AIG 扫描任务",
    created_at: Date.UTC(2026, 2, 10, 9, 0, 0),
    updated_at: Date.UTC(2026, 2, 10, 9, 0, 1),
    ...overrides,
  };
}

function createMonitorStub(overrides?: Partial<AigMonitor>): AigMonitor {
  return {
    watch: vi.fn(),
    getSnapshot: vi.fn(),
    getLatestSessionId: vi.fn(),
    ...overrides,
  };
}

describe("aig-scan-plugin polling flow", () => {
  it("falls back to safe default polling values when config is missing or invalid", () => {
    expect(
      resolvePollingOptions({
        submitPollIntervalMs: 10,
        submitMaxWaitMs: Number.NaN,
        monitorPollIntervalMs: -1,
        monitorMaxWaitMs: 0,
      }),
    ).toEqual({
      submitPollIntervalMs: 2_000,
      submitMaxWaitMs: 10_000,
      monitorPollIntervalMs: 5_000,
      monitorMaxWaitMs: 3 * 60 * 1000,
    });
  });

  it("returns a quick background hand-off when a scan is still running", async () => {
    const client = {
      createTask: vi.fn().mockResolvedValue({ session_id: "sess-1" }),
      getTaskStatus: vi.fn().mockResolvedValue(status({ title: "AI 基础设施安全扫描" })),
      getTaskResult: vi.fn(),
    };
    const monitor = createMonitorStub();

    const tool = createScanInfraTool(client as never, {
      submitPollIntervalMs: 1,
      submitMaxWaitMs: 3,
      monitorPollIntervalMs: 1,
      monitorMaxWaitMs: 3,
    }, monitor);

    const result = await tool.execute("tool-1", {
      target_urls: ["http://127.0.0.1:11434"],
    });
    const text = extractText(result);

    expect(text).toContain("任务已提交");
    expect(text).toContain("Session ID：sess-1");
    expect(text).toContain("AIG 后台执行中");
    expect(text).toContain("插件后台监控：已启动");
    expect(text).toContain("已转入后台继续分析");
    expect(text).not.toContain("STILL_RUNNING");
    expect(text).not.toContain("NEXT_ACTION");
    expect(monitor.watch).toHaveBeenCalledWith("sess-1", { title: "AI 基础设施安全扫描" });
  });

  it("submits agent scan through the same async flow", async () => {
    const client = {
      getAgentNames: vi.fn().mockResolvedValue(["demo-agent"]),
      createTask: vi.fn().mockResolvedValue({ session_id: "sess-agent" }),
      getTaskStatus: vi.fn().mockResolvedValue(status({ title: "AI Agent 安全扫描" })),
      getTaskResult: vi.fn(),
    };
    const monitor = createMonitorStub();

    const tool = createScanAgentTool(client as never, {
      submitPollIntervalMs: 1,
      submitMaxWaitMs: 3,
      monitorPollIntervalMs: 1,
      monitorMaxWaitMs: 3,
    }, monitor);

    const result = await tool.execute("tool-agent", {
      agent_id: "demo-agent",
    });
    const text = extractText(result);

    expect(client.createTask).toHaveBeenCalledWith({
      type: "agent_scan",
      content: {
        agent_id: "demo-agent",
        language: "zh",
      },
    });
    expect(text).toContain("AI Agent 安全扫描");
    expect(text).toContain("Agent：demo-agent");
    expect(text).toContain("已转入后台继续分析");
    expect(monitor.watch).toHaveBeenCalledWith("sess-agent", { title: "AI Agent 安全扫描" });
  });

  it("fails fast when the requested agent_id is not visible in the current namespace", async () => {
    const client = {
      username: "public_user",
      getAgentNames: vi.fn().mockResolvedValue(["demo-agent", "coze-demo"]),
      createTask: vi.fn(),
      getTaskStatus: vi.fn(),
      getTaskResult: vi.fn(),
    };
    const monitor = createMonitorStub();

    const tool = createScanAgentTool(client as never, {
      submitPollIntervalMs: 1,
      submitMaxWaitMs: 3,
      monitorPollIntervalMs: 1,
      monitorMaxWaitMs: 3,
    }, monitor);

    const result = await tool.execute("tool-agent", {
      agent_id: "missing-agent",
    });
    const text = extractText(result);

    expect(text).toContain("未找到 Agent：missing-agent");
    expect(text).toContain("当前 username：public_user");
    expect(text).toContain("当前可用 Agent");
    expect(client.createTask).not.toHaveBeenCalled();
  });

  it("lists visible agent configs for the current username namespace", async () => {
    const client = {
      username: "public_user",
      getAgentNames: vi.fn().mockResolvedValue(["coze-demo", "demo-agent"]),
    };

    const tool = createListAgentsTool(client as never);
    const result = await tool.execute("tool-list", {});
    const text = extractText(result);

    expect(text).toContain("AIG 可扫描 Agent 列表");
    expect(text).toContain("当前 username：public_user");
    expect(text).toContain("- coze-demo");
    expect(text).toContain("- demo-agent");
  });

  it("binds running tasks to the originating session for later notifications", async () => {
    const client = {
      createTask: vi.fn().mockResolvedValue({ session_id: "sess-bound" }),
      getTaskStatus: vi.fn().mockResolvedValue(status({ title: "AI 基础设施安全扫描" })),
      getTaskResult: vi.fn(),
    };
    const monitor = createMonitorStub();

    const tool = createScanInfraTool(client as never, {
      submitPollIntervalMs: 1,
      submitMaxWaitMs: 3,
      monitorPollIntervalMs: 1,
      monitorMaxWaitMs: 3,
    }, monitor, {
      sessionKey: "agent:main:telegram:user-1",
      agentId: "main",
    });

    await tool.execute("tool-bound", {
      target_urls: ["http://127.0.0.1:11434"],
    });

    expect(monitor.watch).toHaveBeenCalledWith("sess-bound", {
      title: "AI 基础设施安全扫描",
      sessionKey: "agent:main:telegram:user-1",
      agentId: "main",
    });
  });

  it("keeps task-status follow-up short and user-facing", async () => {
    const client = {
      getTaskStatus: vi.fn().mockResolvedValue(status({ title: "AI 工具技能扫描（GitHub）" })),
      getTaskResult: vi.fn(),
    };
    const monitor = createMonitorStub({
      getLatestSessionId: vi.fn().mockReturnValue("sess-1"),
    });

    const tool = createCheckScanResultTool(client as never, {
      submitPollIntervalMs: 1,
      submitMaxWaitMs: 3,
      monitorPollIntervalMs: 1,
      monitorMaxWaitMs: 3,
    }, monitor);

    const result = await tool.execute("tool-2", {});
    const text = extractText(result);

    expect(text).toContain("仍在后台执行");
    expect(text).toContain("Session ID：sess-1");
    expect(text).toContain("插件后台监控：运行中");
    expect(text).toContain("AIG 后台任务还在继续跑");
    expect(text).not.toContain("aig_task_status(");
  });

  it("scopes latest-task lookup to the current session", async () => {
    const client = {
      getTaskStatus: vi.fn().mockResolvedValue(status({ title: "AI 工具技能扫描（GitHub）" })),
      getTaskResult: vi.fn(),
    };
    const monitor = createMonitorStub({
      getLatestSessionId: vi.fn().mockReturnValue("sess-scoped"),
    });

    const tool = createCheckScanResultTool(client as never, {
      submitPollIntervalMs: 1,
      submitMaxWaitMs: 3,
      monitorPollIntervalMs: 1,
      monitorMaxWaitMs: 3,
    }, monitor, {
      sessionKey: "agent:main:telegram:user-2",
      agentId: "main",
    });

    await tool.execute("tool-3", {});

    expect(monitor.getLatestSessionId).toHaveBeenCalledWith("agent:main:telegram:user-2");
  });

  it("detects repeated tool-call errors as a stuck task", async () => {
    const reason = detectStuckReason({
      status: "doing",
      log: [
        "Error: execute_shell() missing 1 required positional argument: 'command'",
        "Error: execute_shell() missing 1 required positional argument: 'command'",
        "Error: execute_shell() missing 1 required positional argument: 'command'",
      ].join("\n"),
    });

    expect(reason).toContain("execute_shell");
    expect(reason).toContain("卡住");
  });

  it("formats readme-only AI tool / skills scan results as a project overview section", () => {
    const text = formatResult({
      result: {
        readme: [
          "# 审计总结",
          "",
          "## 1. 项目概述",
          "- **项目名称**: xiaohongshu-skills",
          "- **项目定位**: 小红书自动化工具集",
          "- **主要功能**: 登录、发布、搜索、互动",
          "",
          "## 2. 结论",
          "- 未发现高危问题",
        ].join("\n"),
        score: 100,
        language: "Python",
        llm: "google/gemini-3-flash-preview",
        results: [],
      },
    });

    expect(text).toContain("安全评分：100/100");
    expect(text).toContain("分析模型：google/gemini-3-flash-preview");
    expect(text).toContain("代码语言：Python");
    expect(text).toContain("项目概览");
    expect(text).toContain("审计总结");
    expect(text).toContain("项目名称: xiaohongshu-skills");
    expect(text).toContain("未发现明确的中高危安全风险");
    expect(text).not.toBe("(无结果数据)");
  });

  it("keeps both AI tool overview and security findings when AIG returns both", () => {
    const text = formatResult({
      result: {
        readme: [
          "# 项目概览",
          "",
          "- **项目名称**: xiaohongshu-skills",
          "- **主要功能**: 登录、发布、搜索、互动",
        ].join("\n"),
        score: 82,
        language: "Python",
        llm: "gpt-test",
        results: [
          {
            title: "危险脚本执行",
            desc: "脚本参数未做充分限制",
            risk_type: "Command Injection",
            level: "High",
            suggestion: "限制可执行命令白名单",
          },
        ],
      },
    });

    expect(text).toContain("项目概览");
    expect(text).toContain("项目名称: xiaohongshu-skills");
    expect(text).toContain("安全风险");
    expect(text).toContain("共发现 1 个安全问题");
    expect(text).toContain("危险脚本执行");
    expect(text).toContain("Command Injection");
  });

  it("keeps ai_infra_scan formatting usable for chat", () => {
    const text = formatResult({
      result: {
        score: 72,
        total: 1,
        results: [
          {
            target_url: "http://127.0.0.1:11434",
            summary: "检测到未授权访问风险",
            vulnerabilities: [
              {
                severity: "High",
                name: "Unauthenticated Access",
                summary: "接口未做鉴权",
              },
            ],
          },
        ],
      },
    });

    expect(text).toContain("共发现 1 个漏洞");
    expect(text).toContain("扫描目标：1 个");
    expect(text).toContain("风险分布：High 1");
    expect(text).toContain("聊天摘要");
    expect(text).toContain("[High] 127.0.0.1:11434 - Unauthenticated Access");
  });

  it("formats agent scan results with overview and risk summary", () => {
    const text = formatResult({
      result: {
        score: 84,
        vulnerable_tests: 2,
        readme: [
          "# Agent 概览",
          "",
          "- **目标平台**: Dify",
          "- **主要能力**: 检索、知识库问答、工单创建",
        ].join("\n"),
        results: [
          {
            severity: "High",
            title: "越权访问历史工单",
            category: "ASI02",
            description: "通过提示注入绕过租户隔离，读取其他用户工单摘要",
            remediation: "增加租户边界校验并限制工具入参",
            input: "读取别人的工单",
            output: "返回了其他租户摘要",
          },
          {
            severity: "Low",
            title: "系统提示暴露",
            risk_type: "Prompt Leakage",
            summary: "回复中泄露了部分系统角色说明",
            suggestion: "对系统提示词做最小化暴露处理",
          },
        ],
      },
    });

    expect(text).toContain("共发现 2 个风险项");
    expect(text).toContain("项目概览");
    expect(text).toContain("目标平台: Dify");
    expect(text).toContain("安全风险");
    expect(text).toContain("风险分布：High 1，Low 1");
    expect(text).toContain("越权访问历史工单");
    expect(text).toContain("ASI02");
    expect(text).toContain("Prompt Leakage");
  });

  it("extracts renderable image URLs from AIG results without downloading them again", () => {
    const images = collectResultImages(
      {
        result: {
          results: [
            {
              target_url: "http://9.134.235.140:5174",
              screenshot: "/api/v1/images/demo.jpg",
            },
          ],
          attachment: "https://example.com/report.png?x=1",
          report: "https://example.com/report.pdf",
        },
      },
      { serverUrl: "http://localhost:8088" },
    );

    expect(images).toEqual([
      {
        url: "http://localhost:8088/api/v1/images/demo.jpg",
        alt: "9.134.235.140:5174 页面截图",
      },
      {
        url: "https://example.com/report.png?x=1",
        alt: "AIG 结果图片",
      },
    ]);
  });

  it("builds text-only content with http images as clickable links", () => {
    const content = buildResultContent(
      "扫描完成",
      {
        result: {
          results: [
            {
              target_url: "http://9.134.235.140:5174",
              screenshot: "/api/v1/images/demo.jpg",
            },
          ],
        },
      },
      { serverUrl: "http://localhost:8088" } as never,
    );

    expect(content).toHaveLength(1);
    expect(content[0]).toEqual({
      type: "text",
      text: "扫描完成\n\n[📸 查看截图 1](http://localhost:8088/api/v1/images/demo.jpg)",
    });
  });

  it("embeds https images inline in markdown", () => {
    const content = buildResultContent(
      "扫描完成",
      {
        result: {
          results: [
            {
              target_url: "https://example.com",
              screenshot: "https://example.com/api/v1/images/demo.jpg",
            },
          ],
        },
      },
      { serverUrl: "https://example.com" } as never,
    );

    expect(content).toHaveLength(1);
    expect(content[0]).toEqual({
      type: "text",
      text: "扫描完成\n\n![AIG screenshot 1](https://example.com/api/v1/images/demo.jpg)",
    });
  });

  it("keeps model redteam formatting usable for chat", () => {
    const text = formatResult({
      result: {
        score: 61,
        total: 10,
        jailbreak: 2,
        results: [
          {
            status: "jailbroken",
            modelName: "gpt-test",
            attackMethod: "Raw",
            input: "ignore previous instructions",
            output: "sensitive output",
          },
        ],
      },
    });

    expect(text).toContain("越狱防护失败");
    expect(text).toContain("2/10");
    expect(text).toContain("聊天摘要");
    expect(text).toContain("[gpt-test] Raw");
    expect(text).toContain("攻击：ignore previous instructions");
  });

  it("does not claim all prompts were blocked when redteam results are only a retained sample", () => {
    const text = formatResult({
      result: {
        score: 95,
        baseTotal: 50,
        total: 46,
        errored: 4,
        jailbreak: 2,
        attachment: "report.csv",
        results: Array.from({ length: 20 }, (_, index) => ({
          status: index < 2 ? "Jailbreak" : "Safe",
          modelName: "deepseek/deepseek-v3.2",
          attackMethod: "RedTeam",
          input: `prompt-${index + 1}`,
          output: index < 2 ? `unsafe-${index + 1}` : "blocked",
        })),
      },
    });

    expect(text).toContain("越狱防护失败");
    expect(text).toContain("2/46");
    expect(text).toContain("已评估：46/50 条");
    expect(text).toContain("评估失败：4 条");
    expect(text).toContain("聊天摘要（越狱成功样本）");
    expect(text).not.toContain("全部 20 条攻击 Prompt 均被成功拦截");
  });
});
