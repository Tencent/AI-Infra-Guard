import { Type } from "@sinclair/typebox";
import type { AnyAgentTool } from "openclaw/plugin-sdk/core";
import type { AigClient } from "../client.js";
import { toolResult } from "../result-content.js";

export function createListAgentsTool(client: AigClient): AnyAgentTool {
  return {
    name: "aig_list_agents",
    label: "AIG Agent 列表",
    description:
      "List Agent configs currently visible in AIG under the plugin's configured username namespace. " +
      "Use this before aig_scan_agent when the exact agent_id is unknown. " +
      "The result is already user-facing text and should be passed through directly.",
    parameters: Type.Object({}),

    async execute() {
      let names: string[];
      try {
        names = await client.getAgentNames();
      } catch (err) {
        return toolResult([{
          type: "text" as const,
          text: [
            "❌ 无法获取 AIG Agent 列表。",
            `当前 username：${client.username}`,
            `错误：${String(err)}`,
          ].join("\n"),
        }]);
      }

      const sorted = [...names].sort((a, b) => a.localeCompare(b));
      const lines = [
        `🤖 AIG 可扫描 Agent 列表`,
        `当前 username：${client.username}`,
        `数量：${sorted.length}`,
      ];

      if (sorted.length === 0) {
        lines.push(
          "",
          "当前用户空间下没有可用 Agent 配置。",
          "如果你在 AIG Web UI 里已经保存过 Agent 配置，请检查插件的 username 是否与该配置所属用户一致。",
        );
        if (client.username === "openclaw") {
          lines.push(
            "如果你用的是 aig-opensource 默认公共配置，可尝试把插件 username 改成 public_user 后再查一次。",
          );
        }
      } else {
        lines.push("", ...sorted.map((name) => `- ${name}`));
      }

      return toolResult([{ type: "text" as const, text: lines.join("\n") }]);
    },
  };
}
