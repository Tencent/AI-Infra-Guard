import { Type } from "@sinclair/typebox";
import type { AnyAgentTool } from "openclaw/plugin-sdk/core";
import type { AigMonitor } from "../background-monitor.js";
import type { AigClient } from "../client.js";
import {
  type AigPollingOptions,
  buildCompletedHeader,
  buildErrorText,
  buildStillRunningText,
  formatResult,
  isFailed,
  pollUntilDone,
} from "../poll.js";
import { buildResultContent, toolResult } from "../result-content.js";

type SessionRoute = {
  sessionKey?: string;
  agentId?: string;
};

export function createScanAgentTool(
  client: AigClient,
  polling: AigPollingOptions,
  monitor: AigMonitor,
  sessionRoute?: SessionRoute,
): AnyAgentTool {
  return {
    name: "aig_scan_agent",
    label: "AIG Agent 扫描",
    description:
      "Scan an AI Agent already configured in AIG (Dify, Coze, custom HTTP, etc.) " +
      "for authorization bypass, prompt injection, data leakage, tool abuse, and other agentic risks. " +
      "Use the configured agent_id from AIG Web UI. " +
      "The Agent config is loaded from AIG server-side Agent settings under the plugin's configured username namespace. " +
      "Quickly confirms submission, then either returns the report or a background-running status. " +
      "When a full report is returned, it is already user-facing final text. " +
      "The assistant should passthrough the full report exactly, without shortening, paraphrasing, rewriting, or dropping detail lines.",
    parameters: Type.Object({
      agent_id: Type.String({
        description:
          "Configured agent name/id from AIG Web UI → 设置 → Agent配置. Example: 'demo-agent'",
        minLength: 1,
      }),
      language: Type.Optional(
        Type.String({
          description: "Report language: 'zh' (default) or 'en'.",
        }),
      ),
      eval_model: Type.Optional(
        Type.Object(
          {
            model: Type.String({ description: "LLM model name used by AIG Agent-Scan" }),
            token: Type.String({ description: "API key for the planning / evaluation model" }),
            base_url: Type.String({ description: "Base URL for the planning / evaluation model" }),
          },
          {
            description:
              "Optional planning / evaluation model. If omitted, AIG taskapi falls back to its default available model.",
          },
        ),
      ),
      custom_prompt: Type.Optional(
        Type.String({
          description:
            "Optional short note to emphasize specific risks, shown as task content/title context.",
        }),
      ),
    }),

    async execute(_id, params) {
      try {
        const visibleAgents = await client.getAgentNames();
        if (!visibleAgents.includes(params.agent_id)) {
          const suggestions = [...visibleAgents].sort((a, b) => a.localeCompare(b));
          const lines = [
            `❌ 当前 AIG 用户空间下未找到 Agent：${params.agent_id}`,
            `当前 username：${client.username}`,
            "",
            "这个工具读取的是 AIG 服务器本地已保存的 Agent 配置，不是 OpenClaw 本地文件。",
          ];
          if (suggestions.length > 0) {
            lines.push("", "当前可用 Agent：", ...suggestions.map((name) => `- ${name}`));
          } else {
            lines.push("", "当前用户空间下没有可用 Agent 配置。");
            if (client.username === "openclaw") {
              lines.push("如果你用的是 aig-opensource 默认公共配置，可尝试把插件 username 改成 public_user。");
            }
          }
          lines.push("", "如需继续，请先在 AIG Web UI 保存 Agent 配置，或把插件 username 改成该配置所属用户。");
          return toolResult([{ type: "text" as const, text: lines.join("\n") }]);
        }
      } catch {
        // Best-effort preflight only. If listing agents fails, continue and let taskapi decide.
      }

      const content: Record<string, unknown> = {
        agent_id: params.agent_id,
        language: params.language ?? "zh",
      };
      if (params.eval_model) content.eval_model = params.eval_model;
      if (params.custom_prompt) content.prompt = params.custom_prompt;

      let sessionId: string;
      try {
        const task = await client.createTask({
          type: "agent_scan",
          content,
        } as Parameters<typeof client.createTask>[0]);
        sessionId = task.session_id;
      } catch (err) {
        const message = String(err);
        if (message.includes("获取 Agent 配置失败")) {
          return toolResult([{
            type: "text" as const,
            text: [
              `❌ 提交 Agent 扫描任务失败：AIG 服务器未在当前用户空间找到 Agent 配置。`,
              `当前 username：${client.username}`,
              `Agent：${params.agent_id}`,
              "",
              "这个工具依赖 AIG Web UI 里已保存的 Agent 配置 YAML。",
              "如果配置存在，请检查插件 username 是否与该配置所属用户一致。",
              client.username === "openclaw"
                ? "如果你用的是 aig-opensource 默认公共配置，可尝试把插件 username 改成 public_user。"
                : "",
            ].join("\n"),
          }]);
        }
        return toolResult([{ type: "text" as const, text: `❌ 提交 Agent 扫描任务失败：${message}` }]);
      }

      const title = "AI Agent 安全扫描";
      const extraLines = [`🤖 Agent：${params.agent_id}`];

      const poll = await pollUntilDone(client, sessionId, {
        intervalMs: polling.submitPollIntervalMs,
        maxWaitMs: polling.submitMaxWaitMs,
      });

      if (poll.outcome === "failed" || isFailed(poll.status.status)) {
        return toolResult([{
          type: "text" as const,
          text: buildErrorText({ title, sessionId, elapsedMs: poll.elapsedMs, status: poll.status }),
        }]);
      }

      if (poll.outcome === "timeout") {
        monitor.watch(sessionId, buildMonitorMeta(title, sessionRoute));
        return toolResult([{
          type: "text" as const,
          text: buildStillRunningText({
            title,
            sessionId,
            elapsedMs: poll.elapsedMs,
            currentStatus: poll.status.status,
            extraLines: [...extraLines, `🛰 插件后台监控：已启动`],
            etaHint: "3-10 分钟",
          }),
        }]);
      }

      const reportText = [
        buildCompletedHeader({ title, sessionId, elapsedMs: poll.elapsedMs, extraLines }),
        `📊 扫描结果`,
        formatResult(poll.result, { serverUrl: client.serverUrl }),
      ].join("\n");
      return toolResult(buildResultContent(reportText, poll.result, client));
    },
  };
}

function buildMonitorMeta(title: string, sessionRoute?: SessionRoute) {
  if (!sessionRoute?.sessionKey && !sessionRoute?.agentId) {
    return { title };
  }
  return {
    title,
    sessionKey: sessionRoute.sessionKey,
    agentId: sessionRoute.agentId,
  };
}
