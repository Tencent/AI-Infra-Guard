import { Type } from "@sinclair/typebox";
import type { AnyAgentTool } from "openclaw/plugin-sdk/core";
import type { AigMonitor } from "../background-monitor.js";
import type { AigClient } from "../client.js";
import {
  type AigPollingOptions,
  buildCompletedHeader,
  buildErrorText,
  buildStillRunningText,
  formatResult,
  isFailed,
  pollUntilDone,
} from "../poll.js";
import { buildResultContent, toolResult } from "../result-content.js";

/**
 * aig_scan_ai_tools
 *
 * AI tool / skills scanning for MCP servers and Agent Skills.
 * Supports three scan modes (auto-detected by AIG based on what is provided):
 *   • server_url  → remote/dynamic analysis of a running AI tool service
 *   • github_url  → static analysis — AIG clones & scans the repository / skills project
 *   • local_path  → static analysis — local .zip/.tar.gz is uploaded then scanned
 *
 * Provide exactly one of the three target parameters.
 *
 * Phase 1: submit task → short foreground poll.
 *   • Done quickly     → returns full report.
 *   • Still running     → returns a background-running handoff; LLM then follows up once.
 */
type ModelConfig = { model: string; token: string; base_url?: string };
type SessionRoute = { sessionKey?: string; agentId?: string };

export function createScanAiToolsTool(
  client: AigClient,
  polling: AigPollingOptions,
  monitor: AigMonitor,
  defaultModel?: ModelConfig,
  sessionRoute?: SessionRoute,
): AnyAgentTool {
  return {
    name: "aig_scan_ai_tools",
    label: "AIG AI 工具技能扫描",
    description:
      "Audit AI tool / skills targets for security vulnerabilities, including MCP servers and Agent Skills projects. " +
      "Three modes — provide exactly one: " +
      "(1) server_url: dynamic analysis of a running AI tool service; " +
      "(2) github_url: static analysis by cloning a GitHub repository or skills project; " +
      "(3) local_path: static analysis by uploading a local .zip/.tar.gz archive. " +
      "analysis_model is optional only when a plugin-level defaultModel is configured; otherwise it is required. " +
      "Quickly confirms submission, then either returns the report or a background-running status. " +
      "When a full report is returned, it is already user-facing final text. " +
      "The assistant should passthrough the full report exactly, without shortening, paraphrasing, rewriting, or dropping detail lines.",
    parameters: Type.Object({
      server_url: Type.Optional(
        Type.String({
          description:
            "URL of a running AI tool service to scan dynamically " +
            "(e.g. 'http://localhost:3000' or an SSE/stdio URL). " +
            "Mutually exclusive with github_url / local_path.",
        }),
      ),
      github_url: Type.Optional(
        Type.String({
          description:
            "GitHub repository URL of the AI tool or Agent Skills source code " +
            "(e.g. 'https://github.com/user/mcp-server'). " +
            "AIG will clone and analyze the code statically. " +
            "Mutually exclusive with server_url / local_path.",
        }),
      ),
      local_path: Type.Optional(
        Type.String({
          description:
            "Local path to a .zip, .tar.gz, or .tgz archive of the AI tool or Agent Skills source code. " +
            "The archive will be uploaded to AIG and analyzed statically. " +
            "Mutually exclusive with server_url / github_url.",
        }),
      ),
      analysis_model: Type.Optional(
        Type.Object(
          {
            model:    Type.String({ description: "LLM model name, e.g. 'gpt-4o'" }),
            token:    Type.String({ description: "API key for the LLM" }),
            base_url: Type.Optional(
              Type.String({ description: "Base URL, e.g. 'https://api.openai.com/v1'" }),
            ),
          },
          {
            description:
              "LLM to perform the security analysis. " +
              "If omitted, the plugin must provide defaultModel in its own configuration.",
          },
        ),
      ),
      language: Type.Optional(
        Type.String({ description: "Report language: 'zh' (default) or 'en'" }),
      ),
      thread: Type.Optional(
        Type.Number({
          description: "Concurrent analysis threads (default: 4)",
          minimum: 1, maximum: 16,
        }),
      ),
      custom_prompt: Type.Optional(
        Type.String({
          description:
            "Custom analysis instructions or focus areas for the code scan " +
            "(only applicable when using local_path or github_url).",
        }),
      ),
      headers: Type.Optional(
        Type.Record(
          Type.String(),
          Type.String(),
          {
            description:
              "HTTP headers for the remote AI tool service connection, " +
              "e.g. {\"Authorization\": \"Bearer sk-xxx\"}. " +
              "Only used with server_url mode.",
          },
        ),
      ),
    }),

    async execute(_id, params) {
      const { server_url, github_url, local_path } = params;

      // ── Validate: exactly one mode ─────────────────────────────────────────
      const provided = [server_url, github_url, local_path].filter(
        (v) => v !== undefined && v !== "",
      );
      if (provided.length === 0) {
        return toolResult([{
            type: "text" as const,
            text: [
              "❌ 未指定扫描目标，请提供以下三者之一：",
              "  • server_url  — 运行中的 AI 工具服务地址（动态扫描）",
              "  • github_url  — GitHub 仓库地址（静态代码审计，可用于 MCP / Skills）",
              "  • local_path  — 本地 .zip/.tar.gz 压缩包路径（静态代码审计）",
            ].join("\n"),
          }]);
      }
      if (provided.length > 1) {
        return toolResult([{
            type: "text" as const,
            text: "❌ server_url、github_url、local_path 三者只能提供一个，请重新确认扫描目标。",
          }]);
      }

      // ── Build task content ─────────────────────────────────────────────────
      // Model priority: per-call analysis_model > plugin-level defaultModel.
      const resolvedModel: ModelConfig | undefined = params.analysis_model ?? defaultModel;
      if (!resolvedModel?.model || !resolvedModel?.token) {
        return toolResult([{
          type: "text" as const,
          text: [
            "❌ AI 工具技能扫描必须提供分析模型。",
            "可选方式：",
            "  1. 本次调用显式传 analysis_model",
            "  2. 预先配置插件默认模型：",
            "     openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.model gpt-4o",
            "     openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.token sk-xxx",
            "     openclaw config set plugins.entries.aig-scan-plugin.config.defaultModel.base_url https://api.openai.com/v1",
          ].join("\n"),
        }]);
      }

      const content: Record<string, unknown> = {
        language: params.language ?? "zh",
        thread:   params.thread   ?? 4,
        model: {
          model:    resolvedModel.model,
          token:    resolvedModel.token,
          base_url: resolvedModel.base_url ?? "",
        },
      };

      if (params.headers) content.headers = params.headers;

      let title: string;
      const extraLines: string[] = [];

      if (server_url) {
        // ── Mode: remote AI tool service ─────────────────────────────────────
        // AIG mcp_task.go: transport = "url" when no attachments & content has no "github.com"
        // → serverUrl = params.Content → passed as --server_url to agent-scan
        content.prompt = server_url;
        title = "AI 工具技能扫描（远程服务）";
        extraLines.push(`🌐 目标：${server_url}`);

      } else if (github_url) {
        // ── Mode: GitHub repository — let AIG clone it directly ─────────────
        // AIG mcp_task.go: transport = "code" when content contains "github.com"
        // → GitClone(params.Content, ...) then scans the extracted folder
        content.prompt = github_url;
        title = "AI 工具技能扫描（GitHub）";
        extraLines.push(`📦 仓库：${github_url}`);

      } else {
        // ── Mode: local archive upload ────────────────────────────────────────
        // AIG mcp_task.go: transport = "code" when attachments[] is non-empty
        // → downloads file, extracts, scans folder
        let uploadResult;
        try {
          uploadResult = await client.uploadFile(local_path!);
        } catch (err) {
          return toolResult([{ type: "text" as const, text: `❌ 上传源码失败：${String(err)}` }]);
        }
        content.attachments = uploadResult.fileUrl;
        if (params.custom_prompt) content.prompt = params.custom_prompt;
        title = "AI 工具技能扫描（本地上传）";
        extraLines.push(`📁 源码：${local_path}（已上传）`);
      }

      // ── Submit ─────────────────────────────────────────────────────────────
      let sessionId: string;
      try {
        const task = await client.createTask({
          type: "mcp_scan",
          content,
        } as Parameters<typeof client.createTask>[0]);
        sessionId = task.session_id;
      } catch (err) {
        return toolResult([{ type: "text" as const, text: `❌ 提交 AI 工具技能扫描任务失败：${String(err)}` }]);
      }

      // ── Phase 1: short foreground poll ─────────────────────────────────────
      const poll = await pollUntilDone(client, sessionId, {
        intervalMs: polling.submitPollIntervalMs,
        maxWaitMs: polling.submitMaxWaitMs,
      });

      if (poll.outcome === "failed" || isFailed(poll.status.status)) {
        return toolResult([{
            type: "text" as const,
            text: buildErrorText({ title, sessionId, elapsedMs: poll.elapsedMs, status: poll.status }),
          }]);
      }

      if (poll.outcome === "timeout") {
        monitor.watch(sessionId, buildMonitorMeta(title, sessionRoute));
        return toolResult([{
            type: "text" as const,
            text: buildStillRunningText({
              title,
              sessionId,
              elapsedMs: poll.elapsedMs,
              currentStatus: poll.status.status,
              extraLines: [...extraLines, `🛰 插件后台监控：已启动`],
              etaHint: github_url || local_path ? "2-10 分钟" : "1-5 分钟",
            }),
          }]);
      }

      // ── Completed within 60 s ──────────────────────────────────────────────
      const reportText = [
        buildCompletedHeader({ title, sessionId, elapsedMs: poll.elapsedMs, extraLines }),
        `📊 审计结果`,
        formatResult(poll.result),
      ].join("\n");
      return toolResult(buildResultContent(reportText, poll.result, client));
    },
  };
}

function buildMonitorMeta(title: string, sessionRoute?: SessionRoute) {
  if (!sessionRoute?.sessionKey && !sessionRoute?.agentId) {
    return { title };
  }
  return {
    title,
    sessionKey: sessionRoute.sessionKey,
    agentId: sessionRoute.agentId,
  };
}
