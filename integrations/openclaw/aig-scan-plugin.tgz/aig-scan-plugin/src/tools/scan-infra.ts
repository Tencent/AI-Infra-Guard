import { Type } from "@sinclair/typebox";
import type { AnyAgentTool } from "openclaw/plugin-sdk/core";
import type { AigMonitor } from "../background-monitor.js";
import type { AigClient } from "../client.js";
import {
  type AigPollingOptions,
  buildCompletedHeader,
  buildErrorText,
  buildStillRunningText,
  formatResult,
  isFailed,
  pollUntilDone,
} from "../poll.js";
import { buildResultContent, toolResult } from "../result-content.js";

type SessionRoute = {
  sessionKey?: string;
  agentId?: string;
};

/**
 * aig_scan_infra
 *
 * Phase 1: submit task → short foreground poll.
 *   • Done quickly     → returns full report immediately.
 *   • Still running     → returns a background-running handoff; SKILL.md
 *                         instructs the LLM to do one automatic follow-up result check.
 */
export function createScanInfraTool(
  client: AigClient,
  polling: AigPollingOptions,
  monitor: AigMonitor,
  sessionRoute?: SessionRoute,
): AnyAgentTool {
  return {
    name: "aig_scan_infra",
    label: "AIG 基础设施扫描",
    description:
      "Scan AI infrastructure services (Ollama, LiteLLM, vLLM, Open WebUI, Dify, etc.) " +
      "for known CVEs and security misconfigurations. " +
      "Quickly confirms submission, then either returns the report or a background-running status. " +
      "When a full report is returned, it is already user-facing final text. " +
      "The assistant should passthrough the full report exactly, without shortening, paraphrasing, rewriting, or dropping detail lines.",
    parameters: Type.Object({
      target_urls: Type.Array(Type.String(), {
        description:
          "One or more target service URLs. " +
          "Examples: ['http://192.168.1.10:11434', 'http://9.134.235.140:5173']",
        minItems: 1,
      }),
      timeout: Type.Optional(
        Type.Number({
          description: "Per-target HTTP timeout in seconds (default: 30)",
          minimum: 5,
          maximum: 300,
        }),
      ),
      auth_header: Type.Optional(
        Type.String({
          description: "Authorization header value, e.g. 'Bearer sk-xxx'",
        }),
      ),
      analysis_model: Type.Optional(
        Type.Object(
          {
            model:    Type.String({ description: "LLM model name, e.g. 'gpt-4o'" }),
            token:    Type.String({ description: "API key for the LLM" }),
            base_url: Type.String({ description: "Base URL, e.g. 'https://api.openai.com/v1'" }),
          },
          { description: "Optional LLM for deeper AI-assisted analysis" },
        ),
      ),
    }),

    async execute(_id, params) {
      const content: Record<string, unknown> = {
        target:  params.target_urls,
        timeout: params.timeout ?? 30,
      };
      if (params.auth_header)    content.headers = { Authorization: params.auth_header };
      if (params.analysis_model) content.model   = params.analysis_model;

      // ── Submit ───────────────────────────────────────────────────────────
      let sessionId: string;
      try {
        const task = await client.createTask({
          type: "ai_infra_scan",
          content,
        } as Parameters<typeof client.createTask>[0]);
        sessionId = task.session_id;
      } catch (err) {
        return toolResult([{ type: "text" as const, text: `❌ 提交扫描任务失败：${String(err)}` }]);
      }

      const title    = "AI 基础设施安全扫描";
      const extraLines = [`🎯 目标：${params.target_urls.join(", ")}`];

      // ── Phase 1: short foreground poll ────────────────────────────────────
      const poll = await pollUntilDone(client, sessionId, {
        intervalMs: polling.submitPollIntervalMs,
        maxWaitMs: polling.submitMaxWaitMs,
      });

      if (poll.outcome === "failed" || isFailed(poll.status.status)) {
        return toolResult([{
            type: "text" as const,
            text: buildErrorText({ title, sessionId, elapsedMs: poll.elapsedMs, status: poll.status }),
          }]);
      }

      // Still running after the short foreground wait → Phase 2 handled by aig_check_scan_result
      if (poll.outcome === "timeout") {
        monitor.watch(sessionId, buildMonitorMeta(title, sessionRoute));
        return toolResult([{
            type: "text" as const,
            text: buildStillRunningText({
              title,
              sessionId,
              elapsedMs: poll.elapsedMs,
              currentStatus: poll.status.status,
              extraLines: [...extraLines, `🛰 插件后台监控：已启动`],
              etaHint: "1-5 分钟",
            }),
          }]);
      }

      // ── Completed within 60 s ────────────────────────────────────────────
      const reportText = [
        buildCompletedHeader({ title, sessionId, elapsedMs: poll.elapsedMs, extraLines }),
        `📊 扫描结果`,
        formatResult(poll.result, { serverUrl: client.serverUrl }),
      ].join("\n");
      return toolResult(buildResultContent(reportText, poll.result, client));
    },
  };
}

function buildMonitorMeta(title: string, sessionRoute?: SessionRoute) {
  if (!sessionRoute?.sessionKey && !sessionRoute?.agentId) {
    return { title };
  }
  return {
    title,
    sessionKey: sessionRoute.sessionKey,
    agentId: sessionRoute.agentId,
  };
}
