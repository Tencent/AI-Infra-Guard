import { Type } from "@sinclair/typebox";
import type { AnyAgentTool } from "openclaw/plugin-sdk/core";
import type { AigMonitor } from "../background-monitor.js";
import type { AigClient } from "../client.js";
import {
  type AigPollingOptions,
  buildCompletedHeader,
  buildErrorText,
  buildStillRunningText,
  formatResult,
  isFailed,
  pollUntilDone,
} from "../poll.js";
import { buildResultContent, toolResult } from "../result-content.js";
import { AIG_DATASETS } from "../types.js";

type SessionRoute = {
  sessionKey?: string;
  agentId?: string;
};

/**
 * aig_scan_model_safety
 *
 * Phase 1: submit task → short foreground poll.
 *   • Done quickly     → returns full evaluation report.
 *   • Still running     → returns a background-running handoff; LLM then follows up once.
 */
export function createScanModelSafetyTool(
  client: AigClient,
  polling: AigPollingOptions,
  monitor: AigMonitor,
  sessionRoute?: SessionRoute,
): AnyAgentTool {
  const datasetList = AIG_DATASETS.join(", ");

  return {
    name: "aig_scan_model_safety",
    label: "AIG 越狱安全评测",
    description:
      "Red-team test an LLM's resistance to jailbreak attacks using standardized datasets. " +
      `Available datasets: ${datasetList}. ` +
      "Quickly confirms submission, then either returns the report or a background-running status. " +
      "When a full report is returned, it is already user-facing final text. " +
      "The assistant should passthrough the full report exactly, without shortening, paraphrasing, rewriting, or dropping detail lines.",
    parameters: Type.Object({
      target_model: Type.Object(
        {
          model:    Type.String({ description: "Model to test, e.g. 'gpt-4o'" }),
          token:    Type.String({ description: "API key for the target model" }),
          base_url: Type.String({ description: "API base URL, e.g. 'https://api.openai.com/v1'" }),
        },
        { description: "The LLM to be red-teamed" },
      ),
      eval_model: Type.Optional(
        Type.Object(
          {
            model:    Type.String({ description: "Judge model name" }),
            token:    Type.String({ description: "API key for the judge" }),
            base_url: Type.String({ description: "API base URL for the judge" }),
          },
          { description: "LLM judge (defaults to target_model)" },
        ),
      ),
      datasets: Type.Optional(
        Type.Array(Type.String(), {
          description: `Datasets (default: ["JailBench-Tiny"]). Available: ${datasetList}`,
        }),
      ),
      num_prompts: Type.Optional(
        Type.Number({
          description: "Attack prompts per dataset (default: 50, max: 500)",
          minimum: 1, maximum: 500,
        }),
      ),
      random_seed: Type.Optional(
        Type.Number({ description: "Random seed (default: 42)" }),
      ),
    }),

    async execute(_id, params) {
      const selectedDatasets = params.datasets ?? ["JailBench-Tiny"];
      const evalModel        = params.eval_model ?? params.target_model;

      const invalid = selectedDatasets.filter((d: string) => !AIG_DATASETS.includes(d as never));
      if (invalid.length > 0) {
        return toolResult([{
            type: "text" as const,
            text: `❌ 未知数据集：${invalid.join(", ")}。可用：${datasetList}`,
          }]);
      }

      const content = {
        model: [params.target_model],
        eval_model: evalModel,
        dataset: {
          dataFile:   selectedDatasets,
          numPrompts: params.num_prompts  ?? 50,
          randomSeed: params.random_seed  ?? 42,
        },
        // techniques omitted → AIG defaults to "Raw" (direct jailbreak prompts, no encoding)
      };

      // ── Submit ───────────────────────────────────────────────────────────
      let sessionId: string;
      try {
        const task = await client.createTask({ type: "model_redteam_report", content });
        sessionId = task.session_id;
      } catch (err) {
        return toolResult([{ type: "text" as const, text: `❌ 提交评测任务失败：${String(err)}` }]);
      }

      const title = `LLM 越狱安全评测（Red Team）`;
      const extraLines = [
        `🤖 目标模型：${params.target_model.model}`,
        `📦 数据集：${selectedDatasets.join(", ")}   每集 ${params.num_prompts ?? 50} 条`,
      ];

      // ── Phase 1: short foreground poll ────────────────────────────────────
      const poll = await pollUntilDone(client, sessionId, {
        intervalMs: polling.submitPollIntervalMs,
        maxWaitMs: polling.submitMaxWaitMs,
      });

      if (poll.outcome === "failed" || isFailed(poll.status.status)) {
        return toolResult([{
            type: "text" as const,
            text: buildErrorText({ title, sessionId, elapsedMs: poll.elapsedMs, status: poll.status }),
          }]);
      }

      if (poll.outcome === "timeout") {
        monitor.watch(sessionId, buildMonitorMeta(title, sessionRoute));
        return toolResult([{
            type: "text" as const,
            text: buildStillRunningText({
              title,
              sessionId,
              elapsedMs: poll.elapsedMs,
              currentStatus: poll.status.status,
              extraLines: [...extraLines, `🛰 插件后台监控：已启动`],
              etaHint: "2-8 分钟",
            }),
          }]);
      }

      const reportText = [
        buildCompletedHeader({ title, sessionId, elapsedMs: poll.elapsedMs, extraLines }),
        `📊 评测结果`,
        formatResult(poll.result),
      ].join("\n");
      return toolResult(buildResultContent(reportText, poll.result, client));
    },
  };
}

function buildMonitorMeta(title: string, sessionRoute?: SessionRoute) {
  if (!sessionRoute?.sessionKey && !sessionRoute?.agentId) {
    return { title };
  }
  return {
    title,
    sessionKey: sessionRoute.sessionKey,
    agentId: sessionRoute.agentId,
  };
}
