/**
 * AIG API type definitions.
 * Mirrors the taskapi structs exposed by the opensource AIG server.
 */

// ─── Model config (shared across all task types) ─────────────────────────────

export type AigModelConfig = {
  model: string;
  token: string;
  base_url: string;
};

// ─── Task types ───────────────────────────────────────────────────────────────

export type AigTaskType = "ai_infra_scan" | "mcp_scan" | "model_redteam_report" | "agent_scan";

/** POST /api/v1/app/taskapi/tasks — ai_infra_scan */
export type AigInfraScanContent = {
  target: string[];
  headers?: Record<string, string>;
  timeout?: number;
  model?: AigModelConfig;
};

/** POST /api/v1/app/taskapi/tasks — mcp_scan (AI tool / skills scan, supports MCP / Skills) */
export type AigMcpScanContent = {
  /**
   * Required by aig-opensource taskapi.
   * The plugin may source it from per-call analysis_model or plugin-level defaultModel.
   */
  model: { model: string; token: string; base_url?: string };
  /**
   * For remote server scan: put the AI tool service URL here.
   * For GitHub scan: put the GitHub repo URL here.
   * For local archive scan: put custom analysis instructions here (optional).
   * AIG passes this as --prompt to the agent-scan CLI.
   */
  prompt?: string;
  thread?: number;
  language?: "zh" | "en";
  /** URL returned by /upload — triggers static code analysis (zip/tgz). */
  attachments?: string;
  headers?: Record<string, string>;
};

/** POST /api/v1/app/taskapi/tasks — model_redteam_report */
export type AigRedTeamContent = {
  model: AigModelConfig[];
  eval_model: AigModelConfig;
  dataset: {
    dataFile: string[];
    numPrompts: number;
    randomSeed: number;
  };
  prompt?: string;
  techniques?: string[];
};

/** POST /api/v1/app/taskapi/tasks — agent_scan */
export type AigAgentScanContent = {
  /** Name of an agent config already stored in AIG Web UI ("Agent 配置"). */
  agent_id: string;
  /** Optional LLM used by AIG Agent-Scan for planning/review. Falls back to AIG default model when omitted. */
  eval_model?: AigModelConfig;
  language?: "zh" | "en";
  /** Optional extra scan guidance shown in the task title / content. */
  prompt?: string;
};

// ─── Unified task request ─────────────────────────────────────────────────────

export type AigCreateTaskRequest =
  | { type: "ai_infra_scan"; content: AigInfraScanContent }
  | { type: "mcp_scan"; content: AigMcpScanContent }
  | { type: "model_redteam_report"; content: AigRedTeamContent }
  | { type: "agent_scan"; content: AigAgentScanContent };

// ─── API responses ────────────────────────────────────────────────────────────

/** Unified AIG response envelope */
export type AigResponse<T> = {
  status: 0 | 1;
  message?: string;
  data: T;
};

/** POST /api/v1/app/taskapi/tasks → data */
export type AigCreateTaskData = {
  session_id: string;
};

/** GET /api/v1/app/taskapi/status/{id} → data */
export type AigTaskStatusData = {
  session_id: string;
  /**
   * AIG native status values (from task_manager.go):
   *   todo        = waiting to start   (≈ pending)
   *   doing       = in progress        (≈ running)
   *   done        = finished OK        (≈ completed)
   *   error       = finished with error(≈ failed)
   *   terminated  = manually stopped
   * Legacy aliases (kept for forward-compat): pending, running, completed, failed
   */
  status:
    | "todo"
    | "doing"
    | "done"
    | "error"
    | "terminated"
    | "pending"
    | "running"
    | "completed"
    | "failed";
  title: string;
  created_at: number;
  updated_at: number;
  log?: string;
};

/** POST /api/v1/app/taskapi/upload → data */
export type AigUploadData = {
  fileUrl: string;
  filename: string;
  size: number;
};

// ─── Available jailbreak datasets ────────────────────────────────────────────

export const AIG_DATASETS = [
  "JailBench-Tiny",
  "JailbreakPrompts-Tiny",
  "ChatGPT-Jailbreak-Prompts",
  "JADE-db-v3.0",
  "HarmfulEvalBenchmark",
] as const;

export type AigDataset = (typeof AIG_DATASETS)[number];
